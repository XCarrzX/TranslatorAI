#!/bin/bash

# Apache2 Setup Script for AI Gateway
# Run with sudo: sudo bash setup-apache.sh

echo "=================================="
echo "🌐 AI Gateway Apache2 Setup"
echo "=================================="
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "❌ Please run as root (use sudo)"
    exit 1
fi

# Check if Apache2 is installed
if ! command -v apache2 &> /dev/null; then
    echo "❌ Apache2 is not installed"
    echo "Installing Apache2..."
    apt update
    apt install -y apache2
fi

echo "✅ Apache2 is installed"
echo ""

# Enable required modules
echo "🔧 Enabling required Apache modules..."
a2enmod proxy
a2enmod proxy_http
a2enmod rewrite
a2enmod headers

echo "✅ Modules enabled"
echo ""

# Copy virtual host configuration
echo "📄 Setting up virtual host..."

# Ask for domain name
read -p "Enter your domain name (or press Enter to use localhost): " DOMAIN
if [ -z "$DOMAIN" ]; then
    DOMAIN="localhost"
fi

# Create virtual host configuration
cat > /etc/apache2/sites-available/ai-gateway.conf << EOF
# AI Gateway Apache2 Virtual Host Configuration
<VirtualHost *:80>
    ServerName ${DOMAIN}
    
    # Proxy settings
    ProxyPreserveHost On
    ProxyRequests Off
    
    # Proxy to Node.js on port 422
    ProxyPass / http://localhost:422/
    ProxyPassReverse / http://localhost:422/
    
    # Enable WebSocket support (for streaming)
    RewriteEngine on
    RewriteCond %{HTTP:Upgrade} websocket [NC]
    RewriteCond %{HTTP:Connection} upgrade [NC]
    RewriteRule ^/?(.*) "ws://localhost:422/\$1" [P,L]
    
    # Logs
    ErrorLog \${APACHE_LOG_DIR}/ai-gateway-error.log
    CustomLog \${APACHE_LOG_DIR}/ai-gateway-access.log combined
    
    # Security headers
    Header always set X-Content-Type-Options "nosniff"
    Header always set X-Frame-Options "SAMEORIGIN"
    Header always set X-XSS-Protection "1; mode=block"
</VirtualHost>
EOF

echo "✅ Virtual host configuration created"
echo ""

# Enable site
echo "🔗 Enabling AI Gateway site..."
a2ensite ai-gateway.conf

# Disable default site (optional)
read -p "Disable default Apache site? (y/N): " DISABLE_DEFAULT
if [ "$DISABLE_DEFAULT" = "y" ] || [ "$DISABLE_DEFAULT" = "Y" ]; then
    a2dissite 000-default.conf
    echo "✅ Default site disabled"
fi

echo ""

# Test configuration
echo "🧪 Testing Apache configuration..."
apache2ctl configtest

if [ $? -ne 0 ]; then
    echo "❌ Configuration test failed"
    echo "Please check the configuration"
    exit 1
fi

echo "✅ Configuration test passed"
echo ""

# Reload Apache
echo "🔄 Reloading Apache2..."
systemctl reload apache2

if [ $? -ne 0 ]; then
    echo "❌ Failed to reload Apache2"
    exit 1
fi

echo "✅ Apache2 reloaded"
echo ""

# Display status
echo "=================================="
echo "📊 Apache2 Status"
echo "=================================="
systemctl status apache2 --no-pager -l
echo ""

# Display useful information
echo "=================================="
echo "✅ Setup Complete!"
echo "=================================="
echo ""
echo "📝 Configuration file: /etc/apache2/sites-available/ai-gateway.conf"
echo "📋 Access logs: /var/log/apache2/ai-gateway-access.log"
echo "❌ Error logs: /var/log/apache2/ai-gateway-error.log"
echo ""
echo "🌐 Your AI Gateway is now accessible at:"
if [ "$DOMAIN" = "localhost" ]; then
    echo "   http://localhost"
else
    echo "   http://${DOMAIN}"
fi
echo ""
echo "=================================="
echo "Useful Commands:"
echo "=================================="
echo "Reload Apache:  sudo systemctl reload apache2"
echo "Restart Apache: sudo systemctl restart apache2"
echo "Check status:   sudo systemctl status apache2"
echo "View logs:      sudo tail -f /var/log/apache2/ai-gateway-error.log"
echo "Test config:    sudo apache2ctl configtest"
echo "=================================="
