const express = require('express');
const router = express.Router();
const mappingService = require('../services/mapping.service');

/**
 * GET /models
 * Get all model mappings
 */
router.get('/', (req, res) => {
  try {
    const mappings = mappingService.getAllMappings();
    res.json({
      success: true,
      count: Object.keys(mappings).length,
      mappings: mappings
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve mappings'
    });
  }
});

/**
 * POST /models
 * Add a new model mapping
 * Body: { alias: "aira", realModel: "qwen3.5:27b" }
 */
router.post('/', (req, res) => {
  try {
    const { alias, realModel } = req.body;

    if (!alias || !realModel) {
      return res.status(400).json({
        success: false,
        error: 'Both alias and realModel are required'
      });
    }

    // Check if alias already exists
    if (mappingService.hasAlias(alias)) {
      return res.status(409).json({
        success: false,
        error: 'Alias already exists. Use PUT to update.'
      });
    }

    const success = mappingService.addMapping(alias, realModel);

    if (success) {
      res.status(201).json({
        success: true,
        message: 'Mapping added successfully',
        mapping: { alias, realModel }
      });
    } else {
      res.status(500).json({
        success: false,
        error: 'Failed to add mapping'
      });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

/**
 * PUT /models/:alias
 * Update an existing model mapping
 * Body: { realModel: "new-model-name" }
 */
router.put('/:alias', (req, res) => {
  try {
    const { alias } = req.params;
    const { realModel } = req.body;

    if (!realModel) {
      return res.status(400).json({
        success: false,
        error: 'realModel is required'
      });
    }

    if (!mappingService.hasAlias(alias)) {
      return res.status(404).json({
        success: false,
        error: 'Alias not found'
      });
    }

    const success = mappingService.updateMapping(alias, realModel);

    if (success) {
      res.json({
        success: true,
        message: 'Mapping updated successfully',
        mapping: { alias, realModel }
      });
    } else {
      res.status(500).json({
        success: false,
        error: 'Failed to update mapping'
      });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

/**
 * DELETE /models/:alias
 * Delete a model mapping
 */
router.delete('/:alias', (req, res) => {
  try {
    const { alias } = req.params;

    if (!mappingService.hasAlias(alias)) {
      return res.status(404).json({
        success: false,
        error: 'Alias not found'
      });
    }

    const success = mappingService.deleteMapping(alias);

    if (success) {
      res.json({
        success: true,
        message: 'Mapping deleted successfully',
        alias: alias
      });
    } else {
      res.status(500).json({
        success: false,
        error: 'Failed to delete mapping'
      });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

module.exports = router;
