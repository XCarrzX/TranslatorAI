#!/usr/bin/env node
/**
 * Test script to verify configuration loading
 */

console.log('=================================');
console.log('🔍 Testing Configuration Loading');
console.log('=================================\n');

// Test 1: Load config.js
console.log('Test 1: Loading config.js...');
try {
  const config = require('./config/config');
  console.log('✅ Config loaded successfully');
  console.log('   Port:', config.port);
  console.log('   Ollama Base URL:', config.ollama.baseUrl);
  console.log('   Generate Endpoint:', config.ollama.generateEndpoint);
} catch (error) {
  console.log('❌ Failed to load config.js');
  console.error('   Error:', error.message);
  process.exit(1);
}

// Test 2: Load models.json
console.log('\nTest 2: Loading models.json...');
try {
  const models = require('./config/models.json');
  console.log('✅ Models loaded successfully');
  console.log('   Mappings:', Object.keys(models.mappings).length);
  console.log('   Available aliases:', Object.keys(models.mappings).join(', '));
} catch (error) {
  console.log('❌ Failed to load models.json');
  console.error('   Error:', error.message);
  process.exit(1);
}

// Test 3: Test services can load config
console.log('\nTest 3: Testing service imports...');
try {
  const ollamaService = require('./src/services/ollama.service');
  console.log('✅ Ollama service loaded successfully');
  
  const mappingService = require('./src/services/mapping.service');
  console.log('✅ Mapping service loaded successfully');
  console.log('   Loaded mappings:', Object.keys(mappingService.getAllMappings()).length);
} catch (error) {
  console.log('❌ Failed to load services');
  console.error('   Error:', error.message);
  console.error('   Stack:', error.stack);
  process.exit(1);
}

// Test 4: Test main server can be required
console.log('\nTest 4: Testing server module...');
try {
  const app = require('./src/server');
  console.log('✅ Server module loaded successfully');
} catch (error) {
  console.log('❌ Failed to load server module');
  console.error('   Error:', error.message);
  console.error('   Stack:', error.stack);
  process.exit(1);
}

console.log('\n=================================');
console.log('✅ All tests passed!');
console.log('=================================');
console.log('\nYou can now start the server with:');
console.log('  npm start        - Direct start');
console.log('  npm run pm2:start - Start with PM2');
console.log('=================================\n');
