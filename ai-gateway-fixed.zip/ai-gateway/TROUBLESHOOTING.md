# Troubleshooting Guide

## Error: Cannot find module '../config/config'

### Symptoms
```
Error: Cannot find module '../config/config'
```

### Solutions

#### 1. Run Configuration Test
```bash
cd /path/to/ai-gateway
node test-config.js
```

This will verify all configuration files can be loaded correctly.

#### 2. Check File Permissions
```bash
# Check if config files exist and are readable
ls -la config/
cat config/config.js
cat config/models.json
```

#### 3. Verify Directory Structure
Your directory structure should look like:
```
ai-gateway/
├── config/
│   ├── config.js
│   └── models.json
├── src/
│   ├── server.js
│   ├── routes/
│   ├── services/
│   └── middleware/
├── public/
├── package.json
└── ecosystem.config.js
```

#### 4. Reinstall Dependencies
```bash
rm -rf node_modules package-lock.json
npm install
```

#### 5. Check Node.js Version
```bash
node --version
# Should be v16 or higher
```

#### 6. PM2 Issues
If running with PM2:
```bash
# Stop and delete old process
pm2 delete ai-gateway

# Clear PM2 logs
pm2 flush

# Start fresh
pm2 start ecosystem.config.js

# Check logs
pm2 logs ai-gateway --lines 50
```

#### 7. Manual Test Start
Try starting without PM2:
```bash
cd /path/to/ai-gateway
npm start
```

## Error: Cannot connect to Ollama service

### Solutions

#### 1. Test Ollama Endpoint
```bash
curl -X POST https://aiapi.awwlk.my.id/api/generate \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen3.5:27b",
    "prompt": "Hello",
    "stream": false
  }'
```

#### 2. Check Ollama URL in config.js
```javascript
// config/config.js
module.exports = {
  port: 422,
  ollama: {
    baseUrl: 'https://aiapi.awwlk.my.id',  // ← Check this URL
    generateEndpoint: '/api/generate'
  }
};
```

#### 3. Check Network/Firewall
- Ensure server can access the Ollama endpoint
- Check if HTTPS is accessible (not blocked by firewall)

## Port Already in Use

### Error
```
Error: listen EADDRINUSE: address already in use :::422
```

### Solutions

#### 1. Find and Kill Process
```bash
# Find process using port 422
lsof -i :422
# or
netstat -tulpn | grep 422

# Kill the process
kill -9 <PID>
```

#### 2. Change Port
Edit `config/config.js`:
```javascript
module.exports = {
  port: 8080,  // ← Change to different port
  // ...
};
```

## PM2 Restart Loop

### Symptoms
Process keeps restarting in PM2

### Solutions

#### 1. Check Error Logs
```bash
pm2 logs ai-gateway --err --lines 100
```

#### 2. Increase Max Restarts
Edit `ecosystem.config.js`:
```javascript
module.exports = {
  apps: [{
    name: 'ai-gateway',
    script: './src/server.js',
    instances: 1,
    max_restarts: 10,  // ← Increase this
    min_uptime: '10s',
    max_memory_restart: '500M',
    // ...
  }]
};
```

#### 3. Run Test Config First
```bash
node test-config.js
```

## Module Not Found Errors

### Generic Module Errors

#### 1. Clear and Reinstall
```bash
rm -rf node_modules package-lock.json
npm cache clean --force
npm install
```

#### 2. Check Node Version
```bash
node --version
npm --version
```

#### 3. Install Missing Dependencies
```bash
npm install express axios body-parser cors
```

## Configuration Not Updated

### After changing config files

#### 1. Restart Service
```bash
# If using PM2
pm2 restart ai-gateway

# If using npm
# Stop with Ctrl+C and restart:
npm start
```

#### 2. Clear PM2 Cache
```bash
pm2 delete ai-gateway
pm2 start ecosystem.config.js
```

## Need More Help?

1. Run the test script: `node test-config.js`
2. Check PM2 logs: `pm2 logs ai-gateway --lines 100`
3. Try manual start: `npm start`
4. Check all file paths are correct
5. Verify Node.js version is v16+

## Quick Diagnostic Commands

```bash
# Full diagnostic
cd /path/to/ai-gateway
echo "=== Testing Config ==="
node test-config.js
echo ""
echo "=== PM2 Status ==="
pm2 list
echo ""
echo "=== PM2 Logs ==="
pm2 logs ai-gateway --lines 20 --nostream
```
