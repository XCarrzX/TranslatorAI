# 📁 AI Gateway - Project Structure

Complete file structure of the AI Gateway project.

```
ai-gateway/
│
├── 📄 package.json                 # Node.js dependencies and scripts
├── 📄 README.md                    # Complete documentation
├── 📄 QUICKSTART.md               # Quick start guide
├── 📄 EXAMPLES.md                 # API usage examples
├── 📄 .gitignore                  # Git ignore rules
├── 📄 ecosystem.config.js         # PM2 configuration
│
├── 🔧 deploy.sh                   # Automated deployment script
├── 🔧 setup-apache.sh             # Apache2 setup script
├── 🔧 test-api.sh                 # API testing script
│
├── 📂 config/
│   ├── config.js                  # Server & Ollama configuration
│   ├── models.json                # Model mappings storage
│   └── apache2-vhost.conf         # Apache2 virtual host config
│
├── 📂 src/
│   ├── server.js                  # Main Express server
│   │
│   ├── 📂 services/
│   │   ├── ollama.service.js      # Ollama API client
│   │   └── mapping.service.js     # Model mapping manager
│   │
│   ├── 📂 middleware/
│   │   └── translator.middleware.js  # Model translation
│   │
│   └── 📂 routes/
│       ├── gateway.routes.js      # AI Gateway endpoints
│       └── models.routes.js       # Model management endpoints
│
├── 📂 public/
│   ├── index.html                 # Web UI interface
│   └── app.js                     # Web UI JavaScript
│
└── 📂 logs/                       # PM2 logs (created automatically)
    ├── error.log
    ├── out.log
    └── combined.log
```

## 📋 File Descriptions

### Root Files

- **package.json**: Defines dependencies, scripts, and project metadata
- **README.md**: Complete documentation with setup, usage, and troubleshooting
- **QUICKSTART.md**: 5-minute quick start guide
- **EXAMPLES.md**: cURL and code examples for all API endpoints
- **.gitignore**: Files and directories to exclude from Git
- **ecosystem.config.js**: PM2 process manager configuration

### Scripts

- **deploy.sh**: Automated deployment script (installs deps, starts PM2)
- **setup-apache.sh**: Apache2 reverse proxy setup script
- **test-api.sh**: Automated API testing script

### Configuration Directory (`config/`)

- **config.js**: Server port and Ollama endpoint configuration
- **models.json**: JSON file storing model alias mappings
- **apache2-vhost.conf**: Template for Apache2 virtual host

### Source Directory (`src/`)

#### Main Files
- **server.js**: Express server initialization and routing setup

#### Services (`services/`)
- **ollama.service.js**: Handles all communication with Ollama API
  - Non-streaming requests
  - Streaming requests
  - Error handling
  
- **mapping.service.js**: Manages model mappings
  - Load/save mappings from JSON
  - Translate aliases
  - CRUD operations

#### Middleware (`middleware/`)
- **translator.middleware.js**: Express middleware for model translation
  - Validates model parameter
  - Translates alias to real model
  - Handles not found errors

#### Routes (`routes/`)
- **gateway.routes.js**: AI Gateway endpoint
  - `POST /:model` - Dynamic model endpoint
  
- **models.routes.js**: Model management endpoints
  - `GET /models` - List all mappings
  - `POST /models` - Add new mapping
  - `PUT /models/:alias` - Update mapping
  - `DELETE /models/:alias` - Delete mapping

### Public Directory (`public/`)

- **index.html**: Web UI with modern design
  - Add/Edit/Delete mappings
  - Real-time updates
  - Responsive design
  
- **app.js**: Web UI JavaScript
  - API integration
  - Form handling
  - Dynamic table rendering

### Logs Directory (`logs/`)

Created automatically by PM2:
- **error.log**: Error logs
- **out.log**: Standard output
- **combined.log**: Combined logs

## 🔄 Data Flow

```
1. Client Request
   ↓
2. Express Server (server.js)
   ↓
3. Route Handler (gateway.routes.js)
   ↓
4. Translator Middleware
   ↓
5. Mapping Service (translate alias)
   ↓
6. Ollama Service (call API)
   ↓
7. Response to Client
```

## 📊 Component Dependencies

```
server.js
├── gateway.routes.js
│   ├── translator.middleware.js
│   │   └── mapping.service.js
│   └── ollama.service.js
└── models.routes.js
    └── mapping.service.js
```

## 🎯 Key Features by File

### Model Translation
- **Files**: `translator.middleware.js`, `mapping.service.js`
- **Function**: Translate model aliases to real model names

### Ollama Integration
- **Files**: `ollama.service.js`
- **Function**: Proxy requests to Ollama API with error handling

### Model Management
- **Files**: `mapping.service.js`, `models.routes.js`, `models.json`
- **Function**: CRUD operations for model mappings

### Web Interface
- **Files**: `index.html`, `app.js`
- **Function**: User-friendly UI for managing mappings

### Process Management
- **Files**: `ecosystem.config.js`, `deploy.sh`
- **Function**: Production deployment with PM2

### Reverse Proxy
- **Files**: `apache2-vhost.conf`, `setup-apache.sh`
- **Function**: Apache2 integration for production

## 📝 Configuration Files

| File | Purpose | Format |
|------|---------|--------|
| config.js | Server settings | JavaScript |
| models.json | Model mappings | JSON |
| ecosystem.config.js | PM2 settings | JavaScript |
| apache2-vhost.conf | Apache config | Apache Conf |

## 🔐 Security Considerations

- Model mappings stored in plain JSON (consider encryption for sensitive data)
- No authentication on API endpoints (add if needed)
- CORS enabled (restrict in production)
- Apache security headers configured

## 📦 Dependencies

### Production
- **express**: Web framework
- **axios**: HTTP client for Ollama
- **body-parser**: Request body parsing
- **cors**: Cross-origin resource sharing

### Development
- **nodemon**: Auto-restart on file changes

### Global
- **pm2**: Process manager

## 🚀 Deployment Files

- **deploy.sh**: Automated deployment
- **setup-apache.sh**: Apache setup
- **test-api.sh**: API testing

All scripts are executable and include error handling.

## 📚 Documentation Files

- **README.md**: Main documentation (4000+ words)
- **QUICKSTART.md**: Quick start (5 minutes)
- **EXAMPLES.md**: API examples with curl
- **STRUCTURE.md**: This file

---

**Total Files**: 24
**Total Lines of Code**: ~2,000+
**Languages**: JavaScript, HTML, CSS, Bash
