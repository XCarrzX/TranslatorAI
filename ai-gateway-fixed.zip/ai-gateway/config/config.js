module.exports = {
  port: 422,
  ollama: {
    baseUrl: 'https://aiapi.awwlk.my.id',
    generateEndpoint: '/api/generate'
  }
};
