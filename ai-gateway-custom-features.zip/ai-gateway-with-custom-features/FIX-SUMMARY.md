# 🔧 AI Gateway - Perbaikan Error

## ✅ Masalah yang Diperbaiki

### 1. **Error: Cannot find module '../config/config'**

**Penyebab:**
- Path resolution issue saat runtime
- Kurangnya error handling untuk config loading

**Solusi yang Diterapkan:**
- Menambahkan try-catch dengan fallback config di `src/server.js`
- Menambahkan try-catch dengan fallback config di `src/services/ollama.service.js`
- Menambahkan file existence check di `src/services/mapping.service.js`

### 2. **PM2 Restart Loop**

**Penyebab:**
- Service crash berulang kali karena error
- Konfigurasi PM2 kurang optimal

**Solusi yang Diterapkan:**
- Update `ecosystem.config.js` dengan:
  - `max_restarts: 10`
  - `min_uptime: '10s'`
  - `restart_delay: 4000`
  - `kill_timeout: 5000`

### 3. **API Endpoint Update**

**Perubahan:**
- ❌ Endpoint Lama: `http://103.127.97.215:11434`
- ✅ Endpoint Baru: `https://aiapi.awwlk.my.id`

**File yang Diupdate:**
- `config/config.js` (file utama)
- `README.md` (dokumentasi)
- `QUICKSTART.md` (panduan)

## 📁 File Baru yang Ditambahkan

### 1. `test-config.js`
Script untuk test konfigurasi sebelum start service.

**Cara Pakai:**
```bash
node test-config.js
```

**Fungsi:**
- ✅ Verify config.js dapat dibaca
- ✅ Verify models.json dapat dibaca
- ✅ Test import semua services
- ✅ Test import server module

### 2. `fix-and-restart.sh`
Script otomatis untuk troubleshoot dan restart service.

**Cara Pakai:**
```bash
chmod +x fix-and-restart.sh
./fix-and-restart.sh
```

**Fungsi:**
- ✅ Test konfigurasi
- ✅ Stop PM2 process lama
- ✅ Setup logs directory
- ✅ Check & free port 422
- ✅ Start dengan PM2
- ✅ Verify service running
- ✅ Test health endpoint
- ✅ Show status summary

### 3. `TROUBLESHOOTING.md`
Panduan lengkap troubleshooting.

**Isi:**
- 📖 Penjelasan error umum
- 🔧 Langkah-langkah perbaikan
- 💡 Tips diagnostik
- 📝 Command reference

## 🔄 Cara Deploy Versi Fixed

### Opsi 1: Clean Deploy (Recommended)

```bash
# 1. Backup data mapping (jika ada custom mappings)
cp ai-gateway/config/models.json ~/models.json.backup

# 2. Stop service lama
cd ai-gateway
pm2 stop ai-gateway
pm2 delete ai-gateway

# 3. Backup folder lama
cd ..
mv ai-gateway ai-gateway-old

# 4. Extract versi baru
unzip ai-gateway-fixed.zip
cd ai-gateway

# 5. Restore mapping (jika ada)
cp ~/models.json.backup config/models.json

# 6. Install dependencies
npm install

# 7. Test konfigurasi
node test-config.js

# 8. Start service
./fix-and-restart.sh
```

### Opsi 2: In-Place Update

```bash
# 1. Backup
cd ai-gateway
cp -r config config.backup

# 2. Stop service
pm2 stop ai-gateway

# 3. Update files
# (copy file-file yang sudah diperbaiki)

# 4. Test & restart
node test-config.js
./fix-and-restart.sh
```

## ✨ Fitur Baru

### 1. **Better Error Handling**
- Semua config loading sekarang dengan try-catch
- Fallback config jika file tidak ditemukan
- Logging yang lebih informatif

### 2. **Configuration Test**
- Pre-flight check sebelum start service
- Identify masalah sebelum runtime

### 3. **Auto-Fix Script**
- One-command troubleshoot & restart
- Automated diagnostics
- Status verification

### 4. **Comprehensive Documentation**
- Updated README dengan quick fix guide
- Detailed TROUBLESHOOTING.md
- Step-by-step solutions

## 📋 Checklist Setelah Deploy

- [ ] Run `node test-config.js` - harus pass semua test
- [ ] Run `./fix-and-restart.sh` - service harus start
- [ ] Check `pm2 status` - status harus `online`
- [ ] Test `curl http://localhost:422/health` - harus return OK
- [ ] Check `pm2 logs ai-gateway` - tidak ada error

## 🆘 Jika Masih Error

1. **Jalankan test config:**
   ```bash
   node test-config.js
   ```

2. **Check logs detail:**
   ```bash
   pm2 logs ai-gateway --lines 100
   ```

3. **Manual start untuk debug:**
   ```bash
   npm start
   ```
   (Ctrl+C untuk stop)

4. **Reinstall dependencies:**
   ```bash
   rm -rf node_modules package-lock.json
   npm install
   ```

5. **Lihat TROUBLESHOOTING.md:**
   ```bash
   cat TROUBLESHOOTING.md
   ```

## 📞 Support Commands

```bash
# Status check
pm2 status

# View logs
pm2 logs ai-gateway

# Restart
pm2 restart ai-gateway

# Monitor
pm2 monit

# Test config
node test-config.js

# Auto fix
./fix-and-restart.sh
```

## 📦 Isi Package

```
ai-gateway-fixed.zip
├── config/
│   ├── config.js               ← Updated dengan endpoint baru
│   ├── models.json
│   └── apache2-vhost.conf
├── src/
│   ├── server.js              ← Fixed dengan better error handling
│   ├── services/
│   │   ├── ollama.service.js  ← Fixed dengan fallback config
│   │   └── mapping.service.js ← Fixed dengan existence check
│   ├── middleware/
│   └── routes/
├── public/
├── test-config.js             ← NEW: Configuration test
├── fix-and-restart.sh         ← NEW: Auto-fix script
├── TROUBLESHOOTING.md         ← NEW: Troubleshooting guide
├── README.md                  ← Updated dengan quick fix guide
├── QUICKSTART.md              ← Updated endpoint
├── ecosystem.config.js        ← Updated dengan better PM2 config
├── package.json
└── ...
```

---

**Version:** 1.0.1-fixed
**Date:** 2026-03-01
**Status:** ✅ Ready to deploy
