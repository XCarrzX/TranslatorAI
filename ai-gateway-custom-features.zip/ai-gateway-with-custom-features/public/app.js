// AI Gateway - Model Management Frontend
// =======================================

const API_BASE = '';

// Tab switching
function switchTab(tabName) {
    // Hide all tabs
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    document.querySelectorAll('.tab').forEach(tab => {
        tab.classList.remove('active');
    });

    // Show selected tab
    document.getElementById(`${tabName}-tab`).classList.add('active');
    event.target.classList.add('active');

    // Load data if needed
    if (tabName === 'models') {
        loadModels();
    } else if (tabName === 'test') {
        loadModelsForTest();
    }
}

// Load models
async function loadModels() {
    const container = document.getElementById('models-container');
    container.innerHTML = '<div class="loading">Memuat data model...</div>';

    try {
        const response = await fetch(`${API_BASE}/models`);
        const data = await response.json();

        if (data.success && data.mappings) {
            const mappings = data.mappings;
            const modelCount = Object.keys(mappings).length;

            if (modelCount === 0) {
                container.innerHTML = '<div class="empty-state">Belum ada model. Buat model baru di tab "Buat Model Baru".</div>';
                return;
            }

            let html = '';
            for (const [alias, config] of Object.entries(mappings)) {
                const realModel = typeof config === 'string' ? config : config.realModel;
                const customKnowledge = typeof config === 'object' ? (config.customKnowledge || '') : '';
                const customRules = typeof config === 'object' ? (config.customRules || '') : '';

                html += `
                    <div class="model-card">
                        <div class="model-header">
                            <div>
                                <div class="model-alias">${alias}</div>
                                <div class="model-real">${realModel}</div>
                            </div>
                            <div class="model-actions">
                                <button onclick="editModel('${alias}')">Edit</button>
                                <button class="danger" onclick="deleteModel('${alias}')">Hapus</button>
                            </div>
                        </div>
                        <div class="model-content">
                            ${customKnowledge ? `
                                <div class="model-section">
                                    <div class="model-section-title">📚 Custom Knowledge:</div>
                                    <div class="model-section-content">${escapeHtml(customKnowledge)}</div>
                                </div>
                            ` : ''}
                            ${customRules ? `
                                <div class="model-section">
                                    <div class="model-section-title">📋 Custom Rules:</div>
                                    <div class="model-section-content">${escapeHtml(customRules)}</div>
                                </div>
                            ` : ''}
                            ${!customKnowledge && !customRules ? '<div style="color: #999; font-size: 14px;">Tidak ada custom knowledge atau rules</div>' : ''}
                        </div>
                    </div>
                `;
            }
            container.innerHTML = html;
        } else {
            container.innerHTML = '<div class="empty-state">Gagal memuat data model.</div>';
        }
    } catch (error) {
        console.error('Error loading models:', error);
        container.innerHTML = '<div class="alert alert-error">Error: ' + error.message + '</div>';
    }
}

// Create model
document.getElementById('create-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const alertContainer = document.getElementById('create-alert-container');
    
    const formData = {
        alias: document.getElementById('alias').value,
        realModel: document.getElementById('realModel').value,
        customKnowledge: document.getElementById('customKnowledge').value,
        customRules: document.getElementById('customRules').value
    };

    try {
        const response = await fetch(`${API_BASE}/models`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });

        const data = await response.json();

        if (data.success) {
            alertContainer.innerHTML = '<div class="alert alert-success">✅ Model berhasil dibuat!</div>';
            resetCreateForm();
            setTimeout(() => {
                alertContainer.innerHTML = '';
                // Switch to models tab
                document.querySelector('.tab[onclick*="models"]').click();
            }, 2000);
        } else {
            alertContainer.innerHTML = `<div class="alert alert-error">❌ ${data.error}</div>`;
        }
    } catch (error) {
        alertContainer.innerHTML = `<div class="alert alert-error">❌ Error: ${error.message}</div>`;
    }
});

// Reset create form
function resetCreateForm() {
    document.getElementById('create-form').reset();
}

// Edit model
async function editModel(alias) {
    try {
        const response = await fetch(`${API_BASE}/models/${alias}`);
        const data = await response.json();

        if (data.success) {
            document.getElementById('edit-alias').value = alias;
            document.getElementById('edit-alias-display').value = alias;
            document.getElementById('edit-realModel').value = data.config.realModel;
            document.getElementById('edit-customKnowledge').value = data.config.customKnowledge || '';
            document.getElementById('edit-customRules').value = data.config.customRules || '';

            document.getElementById('edit-modal').classList.add('active');
        }
    } catch (error) {
        alert('Error loading model: ' + error.message);
    }
}

// Close edit modal
function closeEditModal() {
    document.getElementById('edit-modal').classList.remove('active');
}

// Update model
document.getElementById('edit-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const alias = document.getElementById('edit-alias').value;
    const formData = {
        realModel: document.getElementById('edit-realModel').value,
        customKnowledge: document.getElementById('edit-customKnowledge').value,
        customRules: document.getElementById('edit-customRules').value
    };

    try {
        const response = await fetch(`${API_BASE}/models/${alias}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });

        const data = await response.json();

        if (data.success) {
            closeEditModal();
            showAlert('✅ Model berhasil diupdate!', 'success');
            loadModels();
        } else {
            alert('Error: ' + data.error);
        }
    } catch (error) {
        alert('Error: ' + error.message);
    }
});

// Delete model
async function deleteModel(alias) {
    if (!confirm(`Yakin ingin menghapus model "${alias}"?`)) {
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/models/${alias}`, {
            method: 'DELETE'
        });

        const data = await response.json();

        if (data.success) {
            showAlert('✅ Model berhasil dihapus!', 'success');
            loadModels();
        } else {
            showAlert('❌ ' + data.error, 'error');
        }
    } catch (error) {
        showAlert('❌ Error: ' + error.message, 'error');
    }
}

// Load models for test dropdown
async function loadModelsForTest() {
    const select = document.getElementById('test-model');
    
    try {
        const response = await fetch(`${API_BASE}/models`);
        const data = await response.json();

        if (data.success && data.mappings) {
            select.innerHTML = '<option value="">-- Pilih Model --</option>';
            for (const alias of Object.keys(data.mappings)) {
                select.innerHTML += `<option value="${alias}">${alias}</option>`;
            }
        }
    } catch (error) {
        console.error('Error loading models for test:', error);
    }
}

// Test chat
async function testChat() {
    const model = document.getElementById('test-model').value;
    const prompt = document.getElementById('test-prompt').value;
    const alertContainer = document.getElementById('test-alert-container');
    const responseDiv = document.getElementById('test-response');
    const responseContent = document.getElementById('test-response-content');

    if (!model) {
        alertContainer.innerHTML = '<div class="alert alert-error">Pilih model terlebih dahulu!</div>';
        return;
    }

    if (!prompt) {
        alertContainer.innerHTML = '<div class="alert alert-error">Masukkan prompt terlebih dahulu!</div>';
        return;
    }

    alertContainer.innerHTML = '<div class="alert alert-info">Mengirim request...</div>';
    responseDiv.style.display = 'none';

    try {
        const response = await fetch(`${API_BASE}/${model}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                prompt: prompt,
                stream: false
            })
        });

        const data = await response.json();

        if (response.ok) {
            alertContainer.innerHTML = '<div class="alert alert-success">✅ Response diterima!</div>';
            responseContent.textContent = data.response || JSON.stringify(data, null, 2);
            responseDiv.style.display = 'block';
        } else {
            alertContainer.innerHTML = `<div class="alert alert-error">❌ Error: ${data.error || 'Unknown error'}</div>`;
        }
    } catch (error) {
        alertContainer.innerHTML = `<div class="alert alert-error">❌ Error: ${error.message}</div>`;
    }
}

// Show alert
function showAlert(message, type) {
    const container = document.getElementById('alert-container');
    container.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
    setTimeout(() => {
        container.innerHTML = '';
    }, 3000);
}

// Escape HTML
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Load models on page load
document.addEventListener('DOMContentLoaded', () => {
    loadModels();
});
