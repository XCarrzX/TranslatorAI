#!/bin/bash

# AI Gateway - Custom Knowledge & Rules Testing Script
# ====================================================

BASE_URL="http://localhost:422"

echo "=========================================="
echo "AI Gateway Custom Features Test"
echo "=========================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Test 1: Create a customer service bot
echo -e "${YELLOW}Test 1: Creating Customer Service Bot${NC}"
echo "POST /models - Creating cs-bot..."
curl -X POST "$BASE_URL/models" \
  -H "Content-Type: application/json" \
  -d '{
    "alias": "cs-bot",
    "realModel": "qwen3.5:27b",
    "customKnowledge": "Anda adalah customer service dari Toko Online XYZ. Kami menjual elektronik dan gadget. Jam kerja: Senin-Jumat 09:00-17:00 WIB. Alamat toko: Jakarta.",
    "customRules": "1. Selalu gunakan sapaan yang sopan (Bapak/Ibu)\n2. Jika di luar jam kerja, informasikan jam operasional\n3. Berikan nomor WhatsApp untuk urgent: 08123456789\n4. Jangan bahas produk kompetitor"
  }' | jq '.'
echo ""
echo ""

# Test 2: Create a code reviewer bot
echo -e "${YELLOW}Test 2: Creating Code Reviewer Bot${NC}"
echo "POST /models - Creating code-reviewer..."
curl -X POST "$BASE_URL/models" \
  -H "Content-Type: application/json" \
  -d '{
    "alias": "code-reviewer",
    "realModel": "qwen3.5:27b",
    "customKnowledge": "Anda adalah senior software engineer dengan 10+ tahun pengalaman. Expertise: JavaScript, Python, security best practices, dan clean code principles.",
    "customRules": "1. Review code dari aspek: Security, Performance, Readability\n2. Berikan rating 1-10\n3. Identifikasi bug atau vulnerability\n4. Sarankan improvement\n5. Format: Security → Performance → Readability → Rating → Recommendations"
  }' | jq '.'
echo ""
echo ""

# Test 3: Create a teacher bot for children
echo -e "${YELLOW}Test 3: Creating Teacher Bot for Children${NC}"
echo "POST /models - Creating teacher-bot..."
curl -X POST "$BASE_URL/models" \
  -H "Content-Type: application/json" \
  -d '{
    "alias": "teacher-bot",
    "realModel": "qwen3.5:27b",
    "customKnowledge": "Anda adalah Kak Guru, guru yang ramah untuk anak-anak usia 7-12 tahun. Anda mengajar matematika, sains, dan bahasa Indonesia dengan cara yang menyenangkan.",
    "customRules": "1. Gunakan bahasa sederhana yang mudah dipahami anak\n2. Pakai emoji untuk membuat ceria 😊 🎉\n3. Berikan analogi dari kehidupan sehari-hari\n4. Berikan pujian jika jawaban benar\n5. Jangan gunakan istilah teknis yang rumit"
  }' | jq '.'
echo ""
echo ""

# Test 4: Get all models
echo -e "${YELLOW}Test 4: Getting All Models${NC}"
echo "GET /models - Retrieving all models..."
curl -X GET "$BASE_URL/models" | jq '.'
echo ""
echo ""

# Test 5: Get specific model configuration
echo -e "${YELLOW}Test 5: Getting Specific Model Configuration${NC}"
echo "GET /models/cs-bot - Getting cs-bot configuration..."
curl -X GET "$BASE_URL/models/cs-bot" | jq '.'
echo ""
echo ""

# Test 6: Update custom knowledge
echo -e "${YELLOW}Test 6: Updating Custom Knowledge${NC}"
echo "PUT /models/cs-bot - Updating custom knowledge..."
curl -X PUT "$BASE_URL/models/cs-bot" \
  -H "Content-Type: application/json" \
  -d '{
    "customKnowledge": "Anda adalah customer service dari Toko Online XYZ. Kami menjual elektronik dan gadget. Jam kerja: Senin-Sabtu 09:00-21:00 WIB (UPDATED). Alamat toko: Jakarta. Gratis ongkir untuk pembelian di atas Rp 500.000."
  }' | jq '.'
echo ""
echo ""

# Test 7: Update custom rules
echo -e "${YELLOW}Test 7: Updating Custom Rules${NC}"
echo "PUT /models/teacher-bot - Updating custom rules..."
curl -X PUT "$BASE_URL/models/teacher-bot" \
  -H "Content-Type: application/json" \
  -d '{
    "customRules": "1. Gunakan bahasa sederhana\n2. Pakai emoji 😊 🎉 ⭐\n3. Berikan contoh dari kehidupan sehari-hari\n4. Berikan pujian jika benar\n5. Ajukan pertanyaan untuk cek pemahaman (UPDATED RULE)"
  }' | jq '.'
echo ""
echo ""

# Test 8: Test actual chat with cs-bot
echo -e "${YELLOW}Test 8: Testing Chat with CS Bot${NC}"
echo "POST /cs-bot - Testing chat functionality..."
curl -X POST "$BASE_URL/cs-bot" \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "Halo, saya mau tanya jam buka toko kapan ya?",
    "stream": false
  }' | jq '.'
echo ""
echo ""

# Test 9: Test chat with teacher bot
echo -e "${YELLOW}Test 9: Testing Chat with Teacher Bot${NC}"
echo "POST /teacher-bot - Testing chat functionality..."
curl -X POST "$BASE_URL/teacher-bot" \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "Kak, tolong jelaskan apa itu fotosintesis?",
    "stream": false
  }' | jq '.'
echo ""
echo ""

# Test 10: Update entire model configuration
echo -e "${YELLOW}Test 10: Updating Entire Model Configuration${NC}"
echo "PUT /models/code-reviewer - Updating all fields..."
curl -X PUT "$BASE_URL/models/code-reviewer" \
  -H "Content-Type: application/json" \
  -d '{
    "realModel": "qwen3.5:27b",
    "customKnowledge": "Anda adalah principal software engineer dengan 15+ tahun pengalaman. Expertise: Full-stack development, microservices, cloud architecture, security, dan DevOps.",
    "customRules": "1. Review dari aspek: Security, Performance, Scalability, Maintainability\n2. Berikan rating 1-10 dengan justifikasi\n3. Identifikasi critical issues vs nice-to-have\n4. Sarankan refactoring jika diperlukan\n5. Format markdown dengan sections jelas"
  }' | jq '.'
echo ""
echo ""

# Test 11: Verify update
echo -e "${YELLOW}Test 11: Verifying Update${NC}"
echo "GET /models/code-reviewer - Verifying updated configuration..."
curl -X GET "$BASE_URL/models/code-reviewer" | jq '.'
echo ""
echo ""

echo -e "${GREEN}=========================================="
echo "All Tests Completed!"
echo "==========================================${NC}"
echo ""
echo "Next steps:"
echo "1. Check if custom knowledge and rules are being injected properly"
echo "2. Test with actual chat requests"
echo "3. Monitor logs to see middleware injection"
echo ""
