const mappingService = require('../services/mapping.service');

/**
 * Middleware to translate model alias to real model name
 * and inject custom knowledge and rules
 */
const translateModel = (req, res, next) => {
  const modelAlias = req.params.model || req.body.model;

  if (!modelAlias) {
    return res.status(400).json({
      error: 'Model parameter is required'
    });
  }

  console.log(`[Middleware] Received model alias: ${modelAlias}`);

  // Get full model configuration
  const modelConfig = mappingService.getModelConfig(modelAlias);

  if (!modelConfig) {
    console.log(`[Middleware] Model alias not found: ${modelAlias}`);
    return res.status(404).json({
      error: 'Model alias not found',
      alias: modelAlias,
      availableModels: Object.keys(mappingService.getAllMappings())
    });
  }

  // Store translated model and config in request
  req.translatedModel = modelConfig.realModel;
  req.originalAlias = modelAlias;
  req.modelConfig = modelConfig;

  // Inject custom knowledge and rules into the prompt if they exist
  if (req.body && req.body.prompt) {
    let systemPrompt = '';
    
    if (modelConfig.customKnowledge && modelConfig.customKnowledge.trim()) {
      systemPrompt += `## Pengetahuan Kustom:\n${modelConfig.customKnowledge}\n\n`;
    }
    
    if (modelConfig.customRules && modelConfig.customRules.trim()) {
      systemPrompt += `## Peraturan Kustom:\n${modelConfig.customRules}\n\n`;
    }
    
    // Prepend system prompt to user's prompt if custom knowledge or rules exist
    if (systemPrompt) {
      req.body.prompt = systemPrompt + `## Pertanyaan User:\n${req.body.prompt}`;
      console.log(`[Middleware] Injected custom knowledge and rules`);
    }
  }

  console.log(`[Middleware] Translation successful: ${modelAlias} -> ${modelConfig.realModel}`);

  next();
};

module.exports = { translateModel };
