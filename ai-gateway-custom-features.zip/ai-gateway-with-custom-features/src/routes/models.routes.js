const express = require('express');
const router = express.Router();
const mappingService = require('../services/mapping.service');

/**
 * GET /models
 * Get all model mappings
 */
router.get('/', (req, res) => {
  try {
    const mappings = mappingService.getAllMappings();
    res.json({
      success: true,
      count: Object.keys(mappings).length,
      mappings: mappings
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve mappings'
    });
  }
});

/**
 * GET /models/:alias
 * Get detailed configuration for a specific model
 */
router.get('/:alias', (req, res) => {
  try {
    const { alias } = req.params;
    const config = mappingService.getModelConfig(alias);

    if (!config) {
      return res.status(404).json({
        success: false,
        error: 'Model alias not found'
      });
    }

    res.json({
      success: true,
      alias: alias,
      config: config
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve model configuration'
    });
  }
});

/**
 * POST /models
 * Add a new model mapping
 * Body: { 
 *   alias: "aira", 
 *   realModel: "qwen3.5:27b",
 *   customKnowledge: "Your custom knowledge here",
 *   customRules: "Your custom rules here"
 * }
 */
router.post('/', (req, res) => {
  try {
    const { alias, realModel, customKnowledge, customRules } = req.body;

    if (!alias || !realModel) {
      return res.status(400).json({
        success: false,
        error: 'Both alias and realModel are required'
      });
    }

    // Check if alias already exists
    if (mappingService.hasAlias(alias)) {
      return res.status(409).json({
        success: false,
        error: 'Alias already exists. Use PUT to update.'
      });
    }

    const success = mappingService.addMapping(
      alias, 
      realModel, 
      customKnowledge || '', 
      customRules || ''
    );

    if (success) {
      res.status(201).json({
        success: true,
        message: 'Mapping added successfully',
        mapping: { 
          alias, 
          realModel, 
          customKnowledge: customKnowledge || '',
          customRules: customRules || ''
        }
      });
    } else {
      res.status(500).json({
        success: false,
        error: 'Failed to add mapping'
      });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

/**
 * PUT /models/:alias
 * Update an existing model mapping
 * Body: { 
 *   realModel: "new-model-name",
 *   customKnowledge: "Updated knowledge",
 *   customRules: "Updated rules"
 * }
 */
router.put('/:alias', (req, res) => {
  try {
    const { alias } = req.params;
    const { realModel, customKnowledge, customRules } = req.body;

    if (!realModel && customKnowledge === undefined && customRules === undefined) {
      return res.status(400).json({
        success: false,
        error: 'At least one field (realModel, customKnowledge, or customRules) is required'
      });
    }

    if (!mappingService.hasAlias(alias)) {
      return res.status(404).json({
        success: false,
        error: 'Alias not found'
      });
    }

    const updates = {};
    if (realModel !== undefined) updates.realModel = realModel;
    if (customKnowledge !== undefined) updates.customKnowledge = customKnowledge;
    if (customRules !== undefined) updates.customRules = customRules;

    const success = mappingService.updateMapping(alias, updates);

    if (success) {
      const updatedConfig = mappingService.getModelConfig(alias);
      res.json({
        success: true,
        message: 'Mapping updated successfully',
        mapping: { alias, ...updatedConfig }
      });
    } else {
      res.status(500).json({
        success: false,
        error: 'Failed to update mapping'
      });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

/**
 * DELETE /models/:alias
 * Delete a model mapping
 */
router.delete('/:alias', (req, res) => {
  try {
    const { alias } = req.params;

    if (!mappingService.hasAlias(alias)) {
      return res.status(404).json({
        success: false,
        error: 'Alias not found'
      });
    }

    const success = mappingService.deleteMapping(alias);

    if (success) {
      res.json({
        success: true,
        message: 'Mapping deleted successfully',
        alias: alias
      });
    } else {
      res.status(500).json({
        success: false,
        error: 'Failed to delete mapping'
      });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

module.exports = router;
