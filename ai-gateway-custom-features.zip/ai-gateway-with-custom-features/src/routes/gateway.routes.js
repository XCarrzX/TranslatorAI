const express = require('express');
const router = express.Router();
const { translateModel } = require('../middleware/translator.middleware');
const ollamaService = require('../services/ollama.service');

/**
 * POST /:model
 * AI Gateway endpoint - accepts any model alias and proxies to Ollama
 */
router.post('/:model', translateModel, async (req, res) => {
  try {
    const { translatedModel, originalAlias } = req;
    const requestBody = { ...req.body };

    // Replace model alias with real model name
    requestBody.model = translatedModel;

    console.log(`[Gateway] Processing request for alias: ${originalAlias}`);
    console.log(`[Gateway] Real model: ${translatedModel}`);
    console.log(`[Gateway] Stream: ${requestBody.stream || false}`);

    // Handle streaming vs non-streaming
    if (requestBody.stream === true) {
      // Set headers for streaming
      res.setHeader('Content-Type', 'application/x-ndjson');
      res.setHeader('Transfer-Encoding', 'chunked');
      
      await ollamaService.generateStream(requestBody, res);
    } else {
      // Non-streaming response
      const response = await ollamaService.generate(requestBody);
      res.json(response);
    }

  } catch (error) {
    console.error(`[Gateway] Error:`, error);
    
    if (!res.headersSent) {
      res.status(error.status || 500).json({
        error: error.message || 'Internal server error',
        details: error.data || error.error
      });
    }
  }
});

module.exports = router;
