#!/bin/bash

# AI Gateway - Custom Knowledge & Rules Feature
# Installation & Deployment Guide
# =============================================

echo "=========================================="
echo "AI Gateway - Custom Features Installer"
echo "=========================================="
echo ""

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    echo -e "${RED}Error: package.json not found!${NC}"
    echo "Please run this script from the ai-gateway directory."
    exit 1
fi

echo -e "${YELLOW}Step 1: Checking current setup...${NC}"
echo ""

# Backup existing files
echo -e "${YELLOW}Step 2: Backing up existing files...${NC}"
mkdir -p backups
cp config/models.json backups/models.json.backup.$(date +%Y%m%d_%H%M%S) 2>/dev/null
echo -e "${GREEN}✓ Backup created${NC}"
echo ""

# Install dependencies (if needed)
echo -e "${YELLOW}Step 3: Checking dependencies...${NC}"
if [ ! -d "node_modules" ]; then
    echo "Installing dependencies..."
    npm install
else
    echo -e "${GREEN}✓ Dependencies already installed${NC}"
fi
echo ""

# Test the configuration
echo -e "${YELLOW}Step 4: Testing configuration...${NC}"
node -e "
const mapping = require('./src/services/mapping.service');
console.log('✓ MappingService loaded successfully');
console.log('✓ Current models:', Object.keys(mapping.getAllMappings()).join(', '));
" 2>/dev/null

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Configuration OK${NC}"
else
    echo -e "${RED}✗ Configuration error - check your files${NC}"
fi
echo ""

# Restart service
echo -e "${YELLOW}Step 5: Restarting service...${NC}"
if command -v pm2 &> /dev/null; then
    echo "Using PM2..."
    pm2 restart ai-gateway 2>/dev/null || pm2 start ecosystem.config.js
    echo -e "${GREEN}✓ Service restarted with PM2${NC}"
else
    echo "PM2 not found. Please restart manually:"
    echo "  npm start"
    echo "  or"
    echo "  pm2 start ecosystem.config.js"
fi
echo ""

# Test endpoints
echo -e "${YELLOW}Step 6: Testing endpoints...${NC}"
sleep 2

# Test models endpoint
echo "Testing GET /models..."
curl -s http://localhost:422/models > /dev/null
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ GET /models working${NC}"
else
    echo -e "${RED}✗ GET /models failed${NC}"
fi

echo ""
echo -e "${GREEN}=========================================="
echo "Installation Complete!"
echo "==========================================${NC}"
echo ""
echo "Next steps:"
echo "1. Access web UI: http://localhost:422"
echo "2. Or test with curl:"
echo "   curl http://localhost:422/models"
echo ""
echo "3. Run full tests:"
echo "   chmod +x test-custom-features.sh"
echo "   ./test-custom-features.sh"
echo ""
echo "4. Read documentation:"
echo "   - README-CUSTOM.md (Quick start)"
echo "   - CUSTOM-FEATURES.md (Full documentation)"
echo "   - CHANGELOG.md (What changed)"
echo ""
echo "Happy coding! 🚀"
echo ""
