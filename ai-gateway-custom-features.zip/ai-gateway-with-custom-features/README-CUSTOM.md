# AI Gateway - Custom Knowledge & Custom Rules

## 🎯 Fitur Baru

Setiap model di AI Gateway sekarang dapat memiliki:
1. **Custom Knowledge** (Pengetahuan Kustom) - informasi unik yang dimiliki model
2. **Custom Rules** (Peraturan Kustom) - aturan perilaku yang harus diikuti model

## 📦 Files yang Dimodifikasi/Ditambahkan

### Modified Files:
1. **config/models.json** - Format baru dengan custom knowledge & rules
2. **src/services/mapping.service.js** - Tambah method `getModelConfig()` dan update logic
3. **src/routes/models.routes.js** - Tambah GET/:alias endpoint, update POST dan PUT
4. **src/middleware/translator.middleware.js** - Injeksi custom knowledge & rules ke prompt
5. **public/index.html** - UI baru untuk management
6. **public/app.js** - JavaScript logic untuk UI

### New Files:
1. **CUSTOM-FEATURES.md** - Dokumentasi lengkap fitur
2. **test-custom-features.sh** - Script testing otomatis
3. **README-CUSTOM.md** - File ini

## 🚀 Quick Start

### 1. Update Dependencies (jika diperlukan)
```bash
cd ai-gateway
npm install
```

### 2. Jalankan Server
```bash
npm start
# atau
pm2 restart ecosystem.config.js
```

### 3. Akses Web UI
Buka browser: `http://localhost:422` atau `http://your-domain.com`

### 4. Atau Gunakan API Langsung

#### Membuat Model Baru dengan Custom Knowledge & Rules
```bash
curl -X POST http://localhost:422/models \
  -H "Content-Type: application/json" \
  -d '{
    "alias": "cs-bot",
    "realModel": "qwen3.5:27b",
    "customKnowledge": "Anda adalah customer service dari Toko XYZ",
    "customRules": "1. Gunakan bahasa sopan\n2. Berikan solusi jelas"
  }'
```

#### Update Custom Knowledge/Rules
```bash
curl -X PUT http://localhost:422/models/cs-bot \
  -H "Content-Type: application/json" \
  -d '{
    "customKnowledge": "Knowledge yang diupdate",
    "customRules": "Rules yang diupdate"
  }'
```

#### Get Model Configuration
```bash
curl http://localhost:422/models/cs-bot
```

#### Test Chat dengan Model
```bash
curl -X POST http://localhost:422/cs-bot \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "Halo, saya butuh bantuan",
    "stream": false
  }'
```

## 🧪 Testing

### Menggunakan Test Script
```bash
chmod +x test-custom-features.sh
./test-custom-features.sh
```

Script ini akan:
- Membuat 3 contoh model (cs-bot, code-reviewer, teacher-bot)
- Test CRUD operations
- Test chat functionality
- Verify semua endpoint

## 📊 Cara Kerja

### Flow Injection Custom Knowledge & Rules

```
User Request
    ↓
Middleware (translator.middleware.js)
    ↓
Get Model Config (customKnowledge + customRules)
    ↓
Inject to Prompt:
    ## Pengetahuan Kustom:
    [Custom Knowledge]
    
    ## Peraturan Kustom:
    [Custom Rules]
    
    ## Pertanyaan User:
    [Original Prompt]
    ↓
Send to Ollama
    ↓
Return Response
```

## 🎨 Contoh Use Cases

### 1. Customer Service Bot
```javascript
{
  "alias": "cs-bot",
  "realModel": "qwen3.5:27b",
  "customKnowledge": "Anda adalah CS dari Toko ABC. Produk: elektronik. Jam kerja: 09:00-17:00 WIB",
  "customRules": "1. Sapa dengan ramah\n2. Informasikan jam kerja jika di luar jam\n3. Berikan kontak support untuk urgent"
}
```

### 2. Code Reviewer
```javascript
{
  "alias": "code-reviewer",
  "realModel": "qwen3.5:27b",
  "customKnowledge": "Senior engineer 10+ tahun. Expert: security, performance, clean code",
  "customRules": "1. Review: Security → Performance → Readability\n2. Rating 1-10\n3. Identifikasi bug\n4. Sarankan improvement"
}
```

### 3. Teacher for Kids
```javascript
{
  "alias": "teacher-bot",
  "realModel": "qwen3.5:27b",
  "customKnowledge": "Guru ramah untuk anak 7-12 tahun. Mengajar: matematika, sains, bahasa",
  "customRules": "1. Bahasa sederhana\n2. Pakai emoji 😊\n3. Analogi kehidupan sehari-hari\n4. Berikan pujian"
}
```

## 🔄 Backward Compatibility

Format lama tetap didukung:
```json
{
  "mappings": {
    "old-model": "llama2:7b"
  }
}
```

Sistem akan otomatis handle dan return empty string untuk customKnowledge & customRules.

## 📝 API Reference

### GET /models
List semua model dengan konfigurasi lengkap

**Response:**
```json
{
  "success": true,
  "count": 2,
  "mappings": {
    "aira": {
      "realModel": "qwen3.5:27b",
      "customKnowledge": "...",
      "customRules": "..."
    }
  }
}
```

### GET /models/:alias
Get detail konfigurasi model tertentu

**Response:**
```json
{
  "success": true,
  "alias": "aira",
  "config": {
    "realModel": "qwen3.5:27b",
    "customKnowledge": "...",
    "customRules": "..."
  }
}
```

### POST /models
Create model baru

**Body:**
```json
{
  "alias": "my-bot",
  "realModel": "qwen3.5:27b",
  "customKnowledge": "optional",
  "customRules": "optional"
}
```

### PUT /models/:alias
Update model (partial update supported)

**Body:**
```json
{
  "realModel": "optional",
  "customKnowledge": "optional",
  "customRules": "optional"
}
```

### DELETE /models/:alias
Delete model

## ⚠️ Important Notes

1. **Custom Knowledge & Rules** akan diinjeksi ke **setiap request** ke model tersebut
2. Jika terlalu panjang, bisa mempengaruhi response time
3. Model harus "mengikuti" instruksi - tergantung capability model itu sendiri
4. Test secara berkala untuk memastikan model mengikuti rules

## 🐛 Troubleshooting

### Custom Knowledge tidak terinjeksi?
- Pastikan field tidak kosong
- Check log middleware: `[Middleware] Injected custom knowledge and rules`
- Verify dengan GET /models/:alias

### Model tidak mengikuti rules?
- Rules mungkin terlalu kompleks
- Coba simplify rules
- Gunakan bahasa lebih direktif
- Pastikan model cukup capable (gunakan model besar)

### Error saat update?
- Pastikan alias exists
- Check format JSON request
- Lihat response error message

## 📚 Dokumentasi Lengkap

Lihat file **CUSTOM-FEATURES.md** untuk dokumentasi yang lebih lengkap dengan:
- Best practices
- More examples
- Advanced usage
- Migration guide

## 🎯 Next Steps

1. ✅ Buat model pertama Anda dengan custom knowledge & rules
2. ✅ Test dengan berbagai prompt
3. ✅ Fine-tune knowledge & rules berdasarkan hasil
4. ✅ Deploy ke production

## 💡 Tips

- Mulai dengan rules yang simple
- Test secara incremental
- Dokumentasikan knowledge & rules Anda
- Update berkala berdasarkan feedback users

---

**Dibuat dengan ❤️ untuk AI Gateway**
