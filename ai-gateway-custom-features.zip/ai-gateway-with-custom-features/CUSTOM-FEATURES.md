# Custom Knowledge & Custom Rules Feature

## Overview
Setiap model di AI Gateway sekarang memiliki kemampuan untuk memiliki **Custom Knowledge** (Pengetahuan Kustom) dan **Custom Rules** (Peraturan Kustom) yang unik untuk setiap model alias.

## Fitur Utama

### 1. Custom Knowledge (Pengetahuan Kustom)
- Berisi informasi khusus yang ingin Anda berikan ke model
- Contoh: identitas AI, latar belakang, domain knowledge
- Akan ditambahkan di awal prompt setiap request

### 2. Custom Rules (Peraturan Kustom)
- Berisi aturan-aturan yang harus diikuti oleh model
- Contoh: gaya bahasa, batasan topik, format respons
- Akan ditambahkan setelah custom knowledge

## Struktur Data

### Format Baru (Recommended)
```json
{
  "mappings": {
    "aira": {
      "realModel": "qwen3.5:27b",
      "customKnowledge": "Anda adalah Aira, asisten AI yang ramah dan membantu. Anda memiliki pengetahuan tentang teknologi, bisnis, dan kehidupan sehari-hari.",
      "customRules": "1. Selalu gunakan bahasa yang sopan dan profesional\n2. Jika tidak yakin dengan jawaban, katakan dengan jujur\n3. Berikan contoh praktis saat menjelaskan konsep"
    },
    "coder": {
      "realModel": "qwen3.5:27b",
      "customKnowledge": "Anda adalah coding assistant yang ahli dalam berbagai bahasa pemrograman.",
      "customRules": "1. Selalu berikan kode yang bersih dan terdokumentasi\n2. Jelaskan logika di balik solusi\n3. Sarankan best practices"
    }
  }
}
```

### Backward Compatibility
Format lama (string sederhana) masih didukung:
```json
{
  "mappings": {
    "old-model": "llama2:7b"
  }
}
```

## API Endpoints

### 1. Get All Models
```bash
GET /models
```

**Response:**
```json
{
  "success": true,
  "count": 2,
  "mappings": {
    "aira": {
      "realModel": "qwen3.5:27b",
      "customKnowledge": "...",
      "customRules": "..."
    }
  }
}
```

### 2. Get Specific Model Configuration
```bash
GET /models/:alias
```

**Example:**
```bash
curl http://localhost:422/models/aira
```

**Response:**
```json
{
  "success": true,
  "alias": "aira",
  "config": {
    "realModel": "qwen3.5:27b",
    "customKnowledge": "Anda adalah Aira...",
    "customRules": "Selalu gunakan bahasa..."
  }
}
```

### 3. Create New Model with Custom Knowledge & Rules
```bash
POST /models
```

**Request Body:**
```json
{
  "alias": "helper",
  "realModel": "qwen3.5:27b",
  "customKnowledge": "Anda adalah asisten yang membantu dalam pekerjaan sehari-hari",
  "customRules": "Berikan jawaban yang singkat dan jelas"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Mapping added successfully",
  "mapping": {
    "alias": "helper",
    "realModel": "qwen3.5:27b",
    "customKnowledge": "Anda adalah asisten...",
    "customRules": "Berikan jawaban..."
  }
}
```

### 4. Update Model Configuration
```bash
PUT /models/:alias
```

**Update hanya Custom Knowledge:**
```bash
curl -X PUT http://localhost:422/models/aira \
  -H "Content-Type: application/json" \
  -d '{
    "customKnowledge": "Pengetahuan yang diupdate"
  }'
```

**Update hanya Custom Rules:**
```bash
curl -X PUT http://localhost:422/models/aira \
  -H "Content-Type: application/json" \
  -d '{
    "customRules": "Peraturan yang diupdate"
  }'
```

**Update semua field:**
```bash
curl -X PUT http://localhost:422/models/aira \
  -H "Content-Type: application/json" \
  -d '{
    "realModel": "qwen3.5:32b",
    "customKnowledge": "Pengetahuan baru",
    "customRules": "Peraturan baru"
  }'
```

### 5. Delete Model
```bash
DELETE /models/:alias
```

## Cara Kerja

### Flow Injection
1. User mengirim request ke `/:model` endpoint
2. Middleware `translateModel` mengambil konfigurasi model
3. Custom knowledge dan custom rules diinjeksi ke dalam prompt
4. Format injection:
```
## Pengetahuan Kustom:
[Custom Knowledge]

## Peraturan Kustom:
[Custom Rules]

## Pertanyaan User:
[Original Prompt]
```
5. Request diteruskan ke Ollama dengan prompt yang sudah dimodifikasi

## Contoh Penggunaan

### Membuat Model untuk Customer Service
```bash
curl -X POST http://localhost:422/models \
  -H "Content-Type: application/json" \
  -d '{
    "alias": "cs-bot",
    "realModel": "qwen3.5:27b",
    "customKnowledge": "Anda adalah customer service dari PT Maju Jaya. Perusahaan kami bergerak di bidang e-commerce fashion. Jam operasional: Senin-Jumat 09:00-17:00 WIB.",
    "customRules": "1. Selalu sapa customer dengan ramah\n2. Gunakan sapaan Bapak/Ibu\n3. Jika pertanyaan di luar jam kerja, informasikan jam operasional\n4. Jika tidak bisa bantu, berikan kontak support: support@majujaya.com"
  }'
```

### Membuat Model untuk Code Review
```bash
curl -X POST http://localhost:422/models \
  -H "Content-Type: application/json" \
  -d '{
    "alias": "code-reviewer",
    "realModel": "qwen3.5:27b",
    "customKnowledge": "Anda adalah senior software engineer yang ahli dalam code review. Fokus Anda adalah clean code, security, dan performance.",
    "customRules": "1. Identifikasi security vulnerabilities\n2. Sarankan perbaikan performance\n3. Periksa code readability\n4. Berikan rating 1-10 untuk code quality\n5. Format review dengan struktur: Security, Performance, Readability, Recommendations"
  }'
```

### Membuat Model untuk Pembelajaran Anak
```bash
curl -X POST http://localhost:422/models \
  -H "Content-Type: application/json" \
  -d '{
    "alias": "teacher-bot",
    "realModel": "qwen3.5:27b",
    "customKnowledge": "Anda adalah guru yang ramah untuk anak-anak usia 7-12 tahun. Anda mengajarkan matematika, sains, dan bahasa Indonesia.",
    "customRules": "1. Gunakan bahasa yang mudah dipahami anak-anak\n2. Berikan emoji untuk membuat menyenangkan 😊\n3. Gunakan analogi dari kehidupan sehari-hari\n4. Berikan pujian saat anak menjawab benar\n5. Jangan gunakan istilah teknis yang rumit"
  }'
```

## Testing

### Test Request ke Model dengan Custom Knowledge
```bash
curl -X POST http://localhost:422/aira \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "Siapa kamu?",
    "stream": false
  }'
```

Response akan menggunakan custom knowledge yang sudah diset untuk model "aira".

## Migration dari Format Lama

Jika Anda memiliki models.json dengan format lama:
```json
{
  "mappings": {
    "model1": "llama2:7b",
    "model2": "qwen3.5:27b"
  }
}
```

Sistem akan otomatis backward compatible. Namun untuk menggunakan fitur custom knowledge dan rules, update ke format baru:

```bash
# Update model1
curl -X PUT http://localhost:422/models/model1 \
  -H "Content-Type: application/json" \
  -d '{
    "realModel": "llama2:7b",
    "customKnowledge": "Pengetahuan kustom untuk model1",
    "customRules": "Peraturan kustom untuk model1"
  }'
```

## Best Practices

1. **Jelas dan Spesifik**: Tulis custom knowledge dan rules yang jelas dan spesifik
2. **Gunakan Bahasa Konsisten**: Pilih bahasa (Indonesia/Inggris) dan konsisten
3. **Pisahkan Concerns**: 
   - Custom Knowledge = informasi tentang identitas dan pengetahuan
   - Custom Rules = aturan perilaku dan format respons
4. **Test Secara Regular**: Test apakah model mengikuti rules yang diberikan
5. **Update Berkala**: Update knowledge dan rules sesuai kebutuhan bisnis

## Troubleshooting

### Custom Knowledge/Rules tidak muncul?
- Pastikan field tidak kosong string
- Cek log middleware untuk melihat injection
- Verify dengan GET /models/:alias

### Model tidak mengikuti rules?
- Rules mungkin terlalu kompleks atau bertentangan
- Coba sederhanakan rules
- Gunakan bahasa yang lebih direktif

### Performance issue?
- Jika knowledge/rules terlalu panjang, bisa mempengaruhi response time
- Pertimbangkan untuk mempersingkat atau split ke multiple models
