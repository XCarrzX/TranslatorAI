#!/bin/bash

echo "======================================"
echo "🔧 AI Gateway Fix & Restart Script"
echo "======================================"
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Get script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

echo "📂 Working directory: $SCRIPT_DIR"
echo ""

# Step 1: Test configuration
echo "Step 1: Testing configuration..."
if node test-config.js; then
    echo -e "${GREEN}✅ Configuration test passed${NC}"
else
    echo -e "${RED}❌ Configuration test failed${NC}"
    echo "Please check your config files in ./config/"
    exit 1
fi
echo ""

# Step 2: Stop existing PM2 process
echo "Step 2: Stopping existing PM2 process..."
pm2 stop ai-gateway 2>/dev/null
pm2 delete ai-gateway 2>/dev/null
echo -e "${GREEN}✅ Old process stopped${NC}"
echo ""

# Step 3: Create logs directory
echo "Step 3: Setting up logs directory..."
mkdir -p logs
chmod 755 logs
echo -e "${GREEN}✅ Logs directory ready${NC}"
echo ""

# Step 4: Check port availability
echo "Step 4: Checking port 422..."
if lsof -Pi :422 -sTCP:LISTEN -t >/dev/null 2>&1; then
    echo -e "${YELLOW}⚠️  Port 422 is in use${NC}"
    echo "Attempting to free port..."
    PORT_PID=$(lsof -Pi :422 -sTCP:LISTEN -t)
    kill -9 $PORT_PID 2>/dev/null
    sleep 2
    if lsof -Pi :422 -sTCP:LISTEN -t >/dev/null 2>&1; then
        echo -e "${RED}❌ Could not free port 422${NC}"
        echo "Please manually kill the process or change port in config.js"
        exit 1
    fi
fi
echo -e "${GREEN}✅ Port 422 is available${NC}"
echo ""

# Step 5: Start with PM2
echo "Step 5: Starting AI Gateway with PM2..."
pm2 start ecosystem.config.js
sleep 3
echo ""

# Step 6: Check status
echo "Step 6: Checking service status..."
pm2 list | grep ai-gateway
echo ""

# Step 7: Show recent logs
echo "Step 7: Recent logs (last 20 lines)..."
echo "======================================"
pm2 logs ai-gateway --lines 20 --nostream
echo "======================================"
echo ""

# Step 8: Test health endpoint
echo "Step 8: Testing health endpoint..."
sleep 2
if curl -s http://localhost:422/health > /dev/null 2>&1; then
    echo -e "${GREEN}✅ Health endpoint responding${NC}"
    echo ""
    echo "Response:"
    curl -s http://localhost:422/health | json_pp 2>/dev/null || curl -s http://localhost:422/health
else
    echo -e "${RED}❌ Health endpoint not responding${NC}"
    echo "Check PM2 logs for errors:"
    echo "  pm2 logs ai-gateway"
fi
echo ""

# Summary
echo "======================================"
echo "📊 Service Status Summary"
echo "======================================"
pm2 describe ai-gateway 2>/dev/null | grep -E "status|uptime|restarts|memory"
echo ""

echo "======================================"
echo "Useful Commands:"
echo "======================================"
echo "View logs:        pm2 logs ai-gateway"
echo "Restart:          pm2 restart ai-gateway"
echo "Stop:             pm2 stop ai-gateway"
echo "Status:           pm2 status"
echo "Monitor:          pm2 monit"
echo "Test config:      node test-config.js"
echo "======================================"
echo ""
