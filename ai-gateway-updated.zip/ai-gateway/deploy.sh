#!/bin/bash

# AI Gateway Deployment Script
# This script automates the deployment process

echo "=================================="
echo "🤖 AI Gateway Deployment Script"
echo "=================================="
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed"
    echo "Please install Node.js first: https://nodejs.org/"
    exit 1
fi

echo "✅ Node.js version: $(node --version)"

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo "❌ npm is not installed"
    exit 1
fi

echo "✅ npm version: $(npm --version)"
echo ""

# Install dependencies
echo "📦 Installing dependencies..."
npm install

if [ $? -ne 0 ]; then
    echo "❌ Failed to install dependencies"
    exit 1
fi

echo "✅ Dependencies installed"
echo ""

# Create logs directory
echo "📁 Creating logs directory..."
mkdir -p logs
echo "✅ Logs directory created"
echo ""

# Check if PM2 is installed
if ! command -v pm2 &> /dev/null; then
    echo "⚠️  PM2 is not installed globally"
    echo "Installing PM2..."
    npm install -g pm2
    
    if [ $? -ne 0 ]; then
        echo "❌ Failed to install PM2"
        echo "You may need to run: sudo npm install -g pm2"
        exit 1
    fi
fi

echo "✅ PM2 version: $(pm2 --version)"
echo ""

# Start with PM2
echo "🚀 Starting AI Gateway with PM2..."
pm2 start ecosystem.config.js

if [ $? -ne 0 ]; then
    echo "❌ Failed to start with PM2"
    exit 1
fi

echo "✅ AI Gateway started"
echo ""

# Save PM2 configuration
echo "💾 Saving PM2 configuration..."
pm2 save

# Display status
echo ""
echo "=================================="
echo "📊 Current Status"
echo "=================================="
pm2 status
echo ""

# Display useful commands
echo "=================================="
echo "📝 Useful Commands"
echo "=================================="
echo "View logs:     pm2 logs ai-gateway"
echo "Restart:       pm2 restart ai-gateway"
echo "Stop:          pm2 stop ai-gateway"
echo "Monitor:       pm2 monit"
echo ""
echo "Web UI:        http://localhost:422"
echo "Health Check:  curl http://localhost:422/health"
echo ""
echo "=================================="
echo "✅ Deployment Complete!"
echo "=================================="
