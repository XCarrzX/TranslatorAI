# 🚀 Quick Start Guide - AI Gateway

Panduan cepat untuk menjalankan AI Gateway dalam 5 menit!

## Prerequisites

- Node.js (v14 atau lebih tinggi)
- npm
- PM2 (optional, untuk production)
- Apache2 (optional, untuk reverse proxy)
- Ollama service running di `https://aiapi.awwlk.my.id`

## 🎯 Installation (5 Steps)

### 1. Install Dependencies

```bash
npm install
```

### 2. Create Logs Directory

```bash
mkdir -p logs
```

### 3. Start the Server

**Development Mode:**
```bash
npm start
```

**Production Mode with PM2:**
```bash
# Install PM2 globally (one time only)
npm install -g pm2

# Start with PM2
npm run pm2:start
```

### 4. Verify It's Running

```bash
# Check health
curl http://localhost:422/health

# Check models
curl http://localhost:422/models
```

### 5. Open Web UI

Open browser: `http://localhost:422`

## ✅ That's It!

Your AI Gateway is now running on port 422!

## 🧪 Quick Test

Test the gateway with the default "aira" model:

```bash
curl -X POST http://localhost:422/aira \
  -H "Content-Type: application/json" \
  -d '{
    "model": "aira",
    "prompt": "Hello, who are you?",
    "stream": false
  }'
```

## 🎨 Using Web UI

1. Open `http://localhost:422` in browser
2. Add new model mapping:
   - Alias: `assistant`
   - Real Model: `llama3:8b`
3. Click "Add Mapping"
4. Test your new alias!

## 🔧 Common Commands

```bash
# View logs (PM2)
pm2 logs ai-gateway

# Restart
pm2 restart ai-gateway

# Stop
pm2 stop ai-gateway

# Monitor
pm2 monit
```

## 📱 API Endpoints

- `GET /health` - Health check
- `GET /models` - List all mappings
- `POST /models` - Add mapping
- `PUT /models/:alias` - Update mapping
- `DELETE /models/:alias` - Delete mapping
- `POST /:model` - AI Gateway (translate & proxy)

## 🌐 Optional: Setup Apache2 Reverse Proxy

```bash
# Run the setup script
sudo bash setup-apache.sh

# Follow the prompts
# Your gateway will be accessible at http://your-domain.com
```

## 🐛 Troubleshooting

**Port already in use?**
```bash
# Find and kill process on port 422
sudo lsof -i :422
sudo kill -9 <PID>
```

**Can't connect to Ollama?**
- Check Ollama is running at `https://aiapi.awwlk.my.id`
- Verify network connectivity
- Check firewall settings

**PM2 not found?**
```bash
sudo npm install -g pm2
```

## 📚 More Information

- Full documentation: `README.md`
- API examples: `EXAMPLES.md`
- Architecture details: See README

## 🆘 Need Help?

1. Check logs: `pm2 logs ai-gateway`
2. Test Ollama directly: `curl https://aiapi.awwlk.my.id/api/generate`
3. Review configuration: `config/config.js`

---

**Happy coding! 🎉**
