# 🤖 AI Gateway - Model Translator for Ollama

Node.js service yang berfungsi sebagai translator gateway untuk mengubah alias model menjadi model asli di Ollama.

## 📋 Fitur

- ✅ Translate alias model ke model asli Ollama
- ✅ Web UI untuk management mapping
- ✅ RESTful API untuk CRUD operations
- ✅ Support streaming dan non-streaming
- ✅ PM2 process management
- ✅ Apache2 reverse proxy ready
- ✅ Logging dan error handling

## 🏗️ Arsitektur

```
Client → Node.js (Port 422) → Ollama (103.127.97.215:11434)
         [Translator]
```

**Alur Request:**
1. Client request: `POST /aira` dengan `{"model": "aira", "prompt": "..."}`
2. Node.js translate: `aira` → `qwen3.5:27b`
3. Forward ke Ollama: `POST https://aiapi.awwlk.my.id/api/generate`
4. Response dari Ollama → Client

## 📁 Struktur Folder

```
ai-gateway/
├── config/
│   ├── config.js              # Konfigurasi Ollama endpoint & port
│   ├── models.json            # Data mapping model
│   └── apache2-vhost.conf     # Apache2 virtual host config
├── src/
│   ├── server.js              # Main Express server
│   ├── services/
│   │   ├── ollama.service.js  # Service untuk Ollama API
│   │   └── mapping.service.js # Service untuk model mapping
│   ├── middleware/
│   │   └── translator.middleware.js  # Middleware translator
│   └── routes/
│       ├── gateway.routes.js  # AI Gateway routes
│       └── models.routes.js   # Model management routes
├── public/
│   ├── index.html             # Web UI
│   └── app.js                 # Web UI JavaScript
├── logs/                      # PM2 logs directory
├── package.json
├── ecosystem.config.js        # PM2 configuration
└── README.md
```

## 🚀 Installation

### 1. Clone & Install Dependencies

```bash
cd /path/to/your/projects
git clone <your-repo> ai-gateway
cd ai-gateway
npm install
```

### 2. Install PM2 (Global)

```bash
npm install -g pm2
```

### 3. Create Logs Directory

```bash
mkdir -p logs
```

## ⚙️ Configuration

### Edit Ollama Endpoint (Optional)

File: `config/config.js`

```javascript
module.exports = {
  port: 422,
  ollama: {
    baseUrl: 'https://aiapi.awwlk.my.id',  // Ganti jika perlu
    generateEndpoint: '/api/generate'
  }
};
```

### Add Model Mappings

File: `config/models.json`

```json
{
  "mappings": {
    "aira": "qwen3.5:27b",
    "assistant": "llama3:8b",
    "coder": "codellama:13b"
  }
}
```

## 🏃 Running the Application

### Development Mode

```bash
npm run dev
```

### Production Mode with PM2

```bash
# Start
npm run pm2:start

# Check status
pm2 status

# View logs
npm run pm2:logs

# Restart
npm run pm2:restart

# Stop
npm run pm2:stop

# Delete from PM2
pm2 delete ai-gateway
```

### PM2 Advanced Commands

```bash
# Monitor
pm2 monit

# Show detailed info
pm2 show ai-gateway

# Reload (zero-downtime restart)
pm2 reload ai-gateway

# Save PM2 configuration
pm2 save

# Startup on boot
pm2 startup
```

## 🌐 Apache2 Configuration

### 1. Enable Required Modules

```bash
sudo a2enmod proxy
sudo a2enmod proxy_http
sudo a2enmod rewrite
sudo a2enmod headers
```

### 2. Create Virtual Host

```bash
sudo cp config/apache2-vhost.conf /etc/apache2/sites-available/ai-gateway.conf
```

### 3. Edit Virtual Host

```bash
sudo nano /etc/apache2/sites-available/ai-gateway.conf
```

Ganti `your-domain.com` dengan domain Anda, atau gunakan IP server.

### 4. Enable Site

```bash
sudo a2ensite ai-gateway.conf
sudo systemctl reload apache2
```

### 5. Test Configuration

```bash
sudo apache2ctl configtest
sudo systemctl status apache2
```

## 📡 API Endpoints

### AI Gateway

**POST /:model**

Request ke alias model:

```bash
curl -X POST http://localhost:422/aira \
  -H "Content-Type: application/json" \
  -d '{
    "model": "aira",
    "prompt": "Halo, siapa kamu?",
    "stream": false
  }'
```

### Model Management

**GET /models** - List all mappings

```bash
curl http://localhost:422/models
```

Response:
```json
{
  "success": true,
  "count": 1,
  "mappings": {
    "aira": "qwen3.5:27b"
  }
}
```

**POST /models** - Add new mapping

```bash
curl -X POST http://localhost:422/models \
  -H "Content-Type: application/json" \
  -d '{
    "alias": "assistant",
    "realModel": "llama3:8b"
  }'
```

**PUT /models/:alias** - Update mapping

```bash
curl -X PUT http://localhost:422/models/aira \
  -H "Content-Type: application/json" \
  -d '{
    "realModel": "qwen3.5:latest"
  }'
```

**DELETE /models/:alias** - Delete mapping

```bash
curl -X DELETE http://localhost:422/models/aira
```

## 🎨 Web UI

Akses di browser:

```
http://localhost:422
```

Fitur Web UI:
- ✅ View semua mapping
- ✅ Add mapping baru
- ✅ Edit mapping existing
- ✅ Delete mapping
- ✅ Real-time statistics

## 🧪 Testing

### Test Health Check

```bash
curl http://localhost:422/health
```

### Test dengan Model Alias

```bash
# Non-streaming
curl -X POST http://localhost:422/aira \
  -H "Content-Type: application/json" \
  -d '{
    "model": "aira",
    "prompt": "What is AI?",
    "stream": false
  }'

# Streaming
curl -X POST http://localhost:422/aira \
  -H "Content-Type: application/json" \
  -d '{
    "model": "aira",
    "prompt": "Tell me a story",
    "stream": true
  }'
```

### Test Error - Model Not Found

```bash
curl -X POST http://localhost:422/unknown-model \
  -H "Content-Type: application/json" \
  -d '{
    "model": "unknown-model",
    "prompt": "test"
  }'
```

Expected response:
```json
{
  "error": "Model alias not found",
  "alias": "unknown-model",
  "availableModels": ["aira"]
}
```

## 🔧 Troubleshooting

### Port Already in Use

```bash
# Find process using port 422
sudo lsof -i :422

# Kill the process
sudo kill -9 <PID>
```

### PM2 Not Starting

```bash
# Check logs
pm2 logs ai-gateway --err

# Restart
pm2 restart ai-gateway
```

### Cannot Connect to Ollama

- Check if Ollama service is running
- Verify IP and port in `config/config.js`
- Test direct connection:
  ```bash
  curl https://aiapi.awwlk.my.id/api/generate
  ```

### Apache2 502 Bad Gateway

```bash
# Check if Node.js is running
pm2 status

# Check Apache error logs
sudo tail -f /var/log/apache2/ai-gateway-error.log
```

## 📊 Monitoring

### View Logs

```bash
# PM2 logs
pm2 logs ai-gateway

# Apache logs
sudo tail -f /var/log/apache2/ai-gateway-access.log
sudo tail -f /var/log/apache2/ai-gateway-error.log

# Application logs
tail -f logs/combined.log
```

### Monitor Resources

```bash
pm2 monit
```

## 🔒 Security Recommendations

1. **Firewall**: Tutup port 422 dari internet, hanya allow dari Apache
   ```bash
   sudo ufw allow from 127.0.0.1 to any port 422
   ```

2. **HTTPS**: Setup SSL certificate dengan Let's Encrypt
   ```bash
   sudo apt install certbot python3-certbot-apache
   sudo certbot --apache -d your-domain.com
   ```

3. **Rate Limiting**: Add rate limiting di Apache atau gunakan middleware

4. **Authentication**: Tambahkan API key authentication jika diperlukan

## 📝 Logs Location

- **PM2 Logs**: `./logs/`
- **Apache Logs**: `/var/log/apache2/ai-gateway-*.log`
- **Console Logs**: Via `pm2 logs`

## 🆘 Support

Jika ada masalah:
1. Check logs: `pm2 logs ai-gateway`
2. Test Ollama connection
3. Verify configuration files
4. Check firewall rules

## 📄 License

MIT

---

**Created by:** AI Gateway Team
**Version:** 1.0.0
**Last Updated:** 2026
