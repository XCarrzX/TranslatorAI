const fs = require('fs');
const path = require('path');

class ModelMappingService {
  constructor() {
    this.configPath = path.join(__dirname, '../../config/models.json');
    this.loadMappings();
  }

  /**
   * Load mappings from JSON file
   */
  loadMappings() {
    try {
      const data = fs.readFileSync(this.configPath, 'utf8');
      this.mappings = JSON.parse(data).mappings || {};
      console.log('[ModelMapping] Loaded mappings:', Object.keys(this.mappings).length);
    } catch (error) {
      console.error('[ModelMapping] Error loading mappings:', error.message);
      this.mappings = {};
    }
  }

  /**
   * Save mappings to JSON file
   */
  saveMappings() {
    try {
      const data = JSON.stringify({ mappings: this.mappings }, null, 2);
      fs.writeFileSync(this.configPath, data, 'utf8');
      console.log('[ModelMapping] Mappings saved successfully');
      return true;
    } catch (error) {
      console.error('[ModelMapping] Error saving mappings:', error.message);
      return false;
    }
  }

  /**
   * Translate model alias to real model name
   * @param {string} alias - Model alias
   * @returns {string|null} - Real model name or null if not found
   */
  translate(alias) {
    const realModel = this.mappings[alias];
    if (realModel) {
      console.log(`[ModelMapping] Translated: ${alias} -> ${realModel}`);
      return realModel;
    }
    console.log(`[ModelMapping] Alias not found: ${alias}`);
    return null;
  }

  /**
   * Get all mappings
   * @returns {Object} - All mappings
   */
  getAllMappings() {
    return { ...this.mappings };
  }

  /**
   * Add or update a mapping
   * @param {string} alias - Model alias
   * @param {string} realModel - Real model name
   * @returns {boolean} - Success status
   */
  addMapping(alias, realModel) {
    if (!alias || !realModel) {
      return false;
    }
    this.mappings[alias] = realModel;
    return this.saveMappings();
  }

  /**
   * Update a mapping
   * @param {string} alias - Model alias
   * @param {string} newRealModel - New real model name
   * @returns {boolean} - Success status
   */
  updateMapping(alias, newRealModel) {
    if (!this.mappings[alias]) {
      return false;
    }
    this.mappings[alias] = newRealModel;
    return this.saveMappings();
  }

  /**
   * Delete a mapping
   * @param {string} alias - Model alias
   * @returns {boolean} - Success status
   */
  deleteMapping(alias) {
    if (!this.mappings[alias]) {
      return false;
    }
    delete this.mappings[alias];
    return this.saveMappings();
  }

  /**
   * Check if alias exists
   * @param {string} alias - Model alias
   * @returns {boolean}
   */
  hasAlias(alias) {
    return !!this.mappings[alias];
  }
}

module.exports = new ModelMappingService();
