const mappingService = require('../services/mapping.service');

/**
 * Middleware to translate model alias to real model name
 */
const translateModel = (req, res, next) => {
  const modelAlias = req.params.model || req.body.model;

  if (!modelAlias) {
    return res.status(400).json({
      error: 'Model parameter is required'
    });
  }

  console.log(`[Middleware] Received model alias: ${modelAlias}`);

  // Translate alias to real model
  const realModel = mappingService.translate(modelAlias);

  if (!realModel) {
    console.log(`[Middleware] Model alias not found: ${modelAlias}`);
    return res.status(404).json({
      error: 'Model alias not found',
      alias: modelAlias,
      availableModels: Object.keys(mappingService.getAllMappings())
    });
  }

  // Store translated model in request
  req.translatedModel = realModel;
  req.originalAlias = modelAlias;

  console.log(`[Middleware] Translation successful: ${modelAlias} -> ${realModel}`);

  next();
};

module.exports = { translateModel };
