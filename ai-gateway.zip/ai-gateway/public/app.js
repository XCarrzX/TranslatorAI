// API Base URL
const API_BASE = '';

// Global state
let currentMappings = {};
let editingAlias = null;

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    loadMappings();
    setupEventListeners();
});

// Setup event listeners
function setupEventListeners() {
    document.getElementById('addMappingForm').addEventListener('submit', handleAddMapping);
    document.getElementById('editMappingForm').addEventListener('submit', handleEditMapping);
}

// Load all mappings
async function loadMappings() {
    try {
        showLoading(true);
        const response = await fetch(`${API_BASE}/models`);
        const data = await response.json();

        if (data.success) {
            currentMappings = data.mappings;
            renderMappings();
            updateStats();
        } else {
            showAlert('Failed to load mappings', 'error');
        }
    } catch (error) {
        console.error('Error loading mappings:', error);
        showAlert('Error loading mappings: ' + error.message, 'error');
    } finally {
        showLoading(false);
    }
}

// Render mappings table
function renderMappings() {
    const tableBody = document.getElementById('mappingsTableBody');
    const tableContainer = document.getElementById('tableContainer');
    const emptyState = document.getElementById('emptyState');

    const mappingEntries = Object.entries(currentMappings);

    if (mappingEntries.length === 0) {
        tableContainer.style.display = 'none';
        emptyState.style.display = 'block';
        return;
    }

    tableContainer.style.display = 'block';
    emptyState.style.display = 'none';

    tableBody.innerHTML = mappingEntries.map(([alias, realModel]) => `
        <tr>
            <td><span class="badge badge-alias">${escapeHtml(alias)}</span></td>
            <td><span class="badge badge-model">${escapeHtml(realModel)}</span></td>
            <td>
                <button class="btn btn-edit btn-small" onclick="openEditModal('${escapeHtml(alias)}', '${escapeHtml(realModel)}')">Edit</button>
                <button class="btn btn-danger btn-small" onclick="deleteMapping('${escapeHtml(alias)}')">Delete</button>
            </td>
        </tr>
    `).join('');
}

// Update statistics
function updateStats() {
    document.getElementById('totalMappings').textContent = Object.keys(currentMappings).length;
}

// Handle add mapping
async function handleAddMapping(e) {
    e.preventDefault();

    const alias = document.getElementById('aliasInput').value.trim();
    const realModel = document.getElementById('realModelInput').value.trim();

    if (!alias || !realModel) {
        showAlert('Please fill in all fields', 'error');
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/models`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ alias, realModel })
        });

        const data = await response.json();

        if (data.success) {
            showAlert(`Mapping added: ${alias} → ${realModel}`, 'success');
            document.getElementById('addMappingForm').reset();
            await loadMappings();
        } else {
            showAlert(data.error || 'Failed to add mapping', 'error');
        }
    } catch (error) {
        console.error('Error adding mapping:', error);
        showAlert('Error adding mapping: ' + error.message, 'error');
    }
}

// Open edit modal
function openEditModal(alias, realModel) {
    editingAlias = alias;
    document.getElementById('editAliasInput').value = alias;
    document.getElementById('editRealModelInput').value = realModel;
    document.getElementById('editModal').classList.add('active');
}

// Close edit modal
function closeEditModal() {
    editingAlias = null;
    document.getElementById('editModal').classList.remove('active');
    document.getElementById('editMappingForm').reset();
}

// Handle edit mapping
async function handleEditMapping(e) {
    e.preventDefault();

    const realModel = document.getElementById('editRealModelInput').value.trim();

    if (!realModel || !editingAlias) {
        showAlert('Invalid data', 'error');
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/models/${encodeURIComponent(editingAlias)}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ realModel })
        });

        const data = await response.json();

        if (data.success) {
            showAlert(`Mapping updated: ${editingAlias} → ${realModel}`, 'success');
            closeEditModal();
            await loadMappings();
        } else {
            showAlert(data.error || 'Failed to update mapping', 'error');
        }
    } catch (error) {
        console.error('Error updating mapping:', error);
        showAlert('Error updating mapping: ' + error.message, 'error');
    }
}

// Delete mapping
async function deleteMapping(alias) {
    if (!confirm(`Are you sure you want to delete the mapping for "${alias}"?`)) {
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/models/${encodeURIComponent(alias)}`, {
            method: 'DELETE'
        });

        const data = await response.json();

        if (data.success) {
            showAlert(`Mapping deleted: ${alias}`, 'success');
            await loadMappings();
        } else {
            showAlert(data.error || 'Failed to delete mapping', 'error');
        }
    } catch (error) {
        console.error('Error deleting mapping:', error);
        showAlert('Error deleting mapping: ' + error.message, 'error');
    }
}

// Show alert
function showAlert(message, type) {
    const alertContainer = document.getElementById('alertContainer');
    const alertClass = type === 'success' ? 'alert-success' : 'alert-error';
    
    alertContainer.innerHTML = `
        <div class="alert ${alertClass}">
            ${escapeHtml(message)}
        </div>
    `;

    // Auto hide after 5 seconds
    setTimeout(() => {
        alertContainer.innerHTML = '';
    }, 5000);
}

// Show/hide loading state
function showLoading(show) {
    const loadingState = document.getElementById('loadingState');
    loadingState.style.display = show ? 'block' : 'none';
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Close modal when clicking outside
document.getElementById('editModal').addEventListener('click', (e) => {
    if (e.target.id === 'editModal') {
        closeEditModal();
    }
});
