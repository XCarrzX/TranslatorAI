# API Usage Examples - cURL Commands

## Health Check

```bash
curl http://localhost:422/health
```

## Model Management API

### 1. Get All Model Mappings

```bash
curl http://localhost:422/models
```

Response:
```json
{
  "success": true,
  "count": 1,
  "mappings": {
    "aira": "qwen3.5:27b"
  }
}
```

### 2. Add New Model Mapping

```bash
curl -X POST http://localhost:422/models \
  -H "Content-Type: application/json" \
  -d '{
    "alias": "assistant",
    "realModel": "llama3:8b"
  }'
```

Response:
```json
{
  "success": true,
  "message": "Mapping added successfully",
  "mapping": {
    "alias": "assistant",
    "realModel": "llama3:8b"
  }
}
```

### 3. Update Model Mapping

```bash
curl -X PUT http://localhost:422/models/aira \
  -H "Content-Type: application/json" \
  -d '{
    "realModel": "qwen3.5:latest"
  }'
```

Response:
```json
{
  "success": true,
  "message": "Mapping updated successfully",
  "mapping": {
    "alias": "aira",
    "realModel": "qwen3.5:latest"
  }
}
```

### 4. Delete Model Mapping

```bash
curl -X DELETE http://localhost:422/models/assistant
```

Response:
```json
{
  "success": true,
  "message": "Mapping deleted successfully",
  "alias": "assistant"
}
```

## AI Gateway API

### 1. Non-Streaming Request

```bash
curl -X POST http://localhost:422/aira \
  -H "Content-Type: application/json" \
  -d '{
    "model": "aira",
    "prompt": "What is artificial intelligence?",
    "stream": false
  }'
```

### 2. Streaming Request

```bash
curl -X POST http://localhost:422/aira \
  -H "Content-Type: application/json" \
  -d '{
    "model": "aira",
    "prompt": "Tell me a story about AI",
    "stream": true
  }'
```

### 3. Request with Additional Parameters

```bash
curl -X POST http://localhost:422/aira \
  -H "Content-Type: application/json" \
  -d '{
    "model": "aira",
    "prompt": "Explain quantum computing",
    "stream": false,
    "temperature": 0.7,
    "max_tokens": 500
  }'
```

### 4. Multiple Turn Conversation

```bash
curl -X POST http://localhost:422/aira \
  -H "Content-Type: application/json" \
  -d '{
    "model": "aira",
    "messages": [
      {"role": "user", "content": "Hello!"},
      {"role": "assistant", "content": "Hi! How can I help you?"},
      {"role": "user", "content": "What is 2+2?"}
    ],
    "stream": false
  }'
```

## Error Handling Examples

### 1. Model Alias Not Found

```bash
curl -X POST http://localhost:422/unknown \
  -H "Content-Type: application/json" \
  -d '{
    "model": "unknown",
    "prompt": "test"
  }'
```

Response:
```json
{
  "error": "Model alias not found",
  "alias": "unknown",
  "availableModels": ["aira"]
}
```

### 2. Missing Required Fields

```bash
curl -X POST http://localhost:422/models \
  -H "Content-Type: application/json" \
  -d '{
    "alias": "test"
  }'
```

Response:
```json
{
  "success": false,
  "error": "Both alias and realModel are required"
}
```

### 3. Update Non-Existent Mapping

```bash
curl -X PUT http://localhost:422/models/nonexistent \
  -H "Content-Type: application/json" \
  -d '{
    "realModel": "test:latest"
  }'
```

Response:
```json
{
  "success": false,
  "error": "Alias not found"
}
```

## Using with Different Tools

### Using with HTTPie

```bash
# Install httpie
sudo apt install httpie

# Get all models
http GET localhost:422/models

# Add mapping
http POST localhost:422/models alias=coder realModel=codellama:13b

# AI request
http POST localhost:422/aira model=aira prompt="Hello" stream:=false
```

### Using with Postman

Import this collection:

```json
{
  "info": {
    "name": "AI Gateway API",
    "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
  },
  "item": [
    {
      "name": "Get Models",
      "request": {
        "method": "GET",
        "header": [],
        "url": "http://localhost:422/models"
      }
    },
    {
      "name": "Add Model",
      "request": {
        "method": "POST",
        "header": [{"key": "Content-Type", "value": "application/json"}],
        "body": {
          "mode": "raw",
          "raw": "{\"alias\":\"test\",\"realModel\":\"test:latest\"}"
        },
        "url": "http://localhost:422/models"
      }
    },
    {
      "name": "AI Request",
      "request": {
        "method": "POST",
        "header": [{"key": "Content-Type", "value": "application/json"}],
        "body": {
          "mode": "raw",
          "raw": "{\"model\":\"aira\",\"prompt\":\"Hello\",\"stream\":false}"
        },
        "url": "http://localhost:422/aira"
      }
    }
  ]
}
```

### Using with JavaScript/Node.js

```javascript
const axios = require('axios');

// Get all models
async function getAllModels() {
  const response = await axios.get('http://localhost:422/models');
  console.log(response.data);
}

// Add model mapping
async function addModel() {
  const response = await axios.post('http://localhost:422/models', {
    alias: 'assistant',
    realModel: 'llama3:8b'
  });
  console.log(response.data);
}

// AI request
async function generateText() {
  const response = await axios.post('http://localhost:422/aira', {
    model: 'aira',
    prompt: 'What is AI?',
    stream: false
  });
  console.log(response.data);
}
```

### Using with Python

```python
import requests

# Get all models
response = requests.get('http://localhost:422/models')
print(response.json())

# Add model mapping
response = requests.post('http://localhost:422/models', 
    json={'alias': 'assistant', 'realModel': 'llama3:8b'})
print(response.json())

# AI request
response = requests.post('http://localhost:422/aira',
    json={'model': 'aira', 'prompt': 'What is AI?', 'stream': False})
print(response.json())
```

## Rate Limiting and Best Practices

1. **Connection Timeout**: Set appropriate timeouts for long-running requests
2. **Retry Logic**: Implement exponential backoff for failed requests
3. **Error Handling**: Always check response status codes
4. **Streaming**: Use streaming for long responses to reduce wait time
5. **Keep-Alive**: Use HTTP keep-alive for multiple requests

## Common Response Codes

- `200` - Success
- `201` - Created (new resource)
- `400` - Bad Request (missing/invalid parameters)
- `404` - Not Found (model alias or endpoint)
- `409` - Conflict (alias already exists)
- `500` - Internal Server Error
- `503` - Service Unavailable (cannot connect to Ollama)
