const axios = require('axios');
const config = require('../config/config');

class OllamaService {
  constructor() {
    this.baseUrl = config.ollama.baseUrl;
    this.generateEndpoint = config.ollama.generateEndpoint;
  }

  /**
   * Generate response from Ollama
   * @param {Object} requestBody - Request body with model, prompt, stream, etc.
   * @returns {Promise<Object>} - Ollama response
   */
  async generate(requestBody) {
    try {
      const url = `${this.baseUrl}${this.generateEndpoint}`;
      
      console.log(`[Ollama] Sending request to: ${url}`);
      console.log(`[Ollama] Model: ${requestBody.model}`);
      console.log(`[Ollama] Prompt length: ${requestBody.prompt?.length || 0} chars`);

      const response = await axios.post(url, requestBody, {
        headers: {
          'Content-Type': 'application/json'
        },
        timeout: 300000 // 5 minutes timeout
      });

      console.log(`[Ollama] Response received successfully`);
      return response.data;
    } catch (error) {
      console.error(`[Ollama] Error:`, error.message);
      
      if (error.response) {
        // Ollama returned an error
        throw {
          status: error.response.status,
          message: error.response.data?.error || 'Ollama API error',
          data: error.response.data
        };
      } else if (error.request) {
        // No response received
        throw {
          status: 503,
          message: 'Cannot connect to Ollama service',
          error: error.message
        };
      } else {
        // Other errors
        throw {
          status: 500,
          message: 'Internal server error',
          error: error.message
        };
      }
    }
  }

  /**
   * Stream generate response from Ollama
   * @param {Object} requestBody - Request body
   * @param {Object} res - Express response object
   */
  async generateStream(requestBody, res) {
    try {
      const url = `${this.baseUrl}${this.generateEndpoint}`;
      
      console.log(`[Ollama] Streaming request to: ${url}`);
      console.log(`[Ollama] Model: ${requestBody.model}`);

      const response = await axios.post(url, requestBody, {
        headers: {
          'Content-Type': 'application/json'
        },
        responseType: 'stream',
        timeout: 300000
      });

      // Pipe the stream directly to client
      response.data.pipe(res);

      response.data.on('end', () => {
        console.log(`[Ollama] Stream completed`);
      });

      response.data.on('error', (error) => {
        console.error(`[Ollama] Stream error:`, error.message);
        if (!res.headersSent) {
          res.status(500).json({ error: 'Stream error occurred' });
        }
      });

    } catch (error) {
      console.error(`[Ollama] Stream error:`, error.message);
      
      if (!res.headersSent) {
        if (error.response) {
          res.status(error.response.status).json({
            error: error.response.data?.error || 'Ollama API error'
          });
        } else if (error.request) {
          res.status(503).json({
            error: 'Cannot connect to Ollama service'
          });
        } else {
          res.status(500).json({
            error: 'Internal server error'
          });
        }
      }
    }
  }
}

module.exports = new OllamaService();
