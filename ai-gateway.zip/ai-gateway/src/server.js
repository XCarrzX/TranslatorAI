const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const config = require('../config/config');

// Import routes
const gatewayRoutes = require('./routes/gateway.routes');
const modelsRoutes = require('./routes/models.routes');

// Initialize Express app
const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Logging middleware
app.use((req, res, next) => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${req.method} ${req.path}`);
  next();
});

// Serve static files (Web UI)
app.use(express.static(path.join(__dirname, '../public')));

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'AI Gateway',
    timestamp: new Date().toISOString(),
    version: '1.0.0'
  });
});

// API Routes
app.use('/models', modelsRoutes);  // Model management endpoints

// Gateway routes - must be last to catch dynamic model routes
app.use('/', gatewayRoutes);  // AI Gateway endpoints

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    error: 'Endpoint not found',
    path: req.path,
    method: req.method
  });
});

// Error handler
app.use((err, req, res, next) => {
  console.error('[Server Error]:', err);
  res.status(500).json({
    error: 'Internal server error',
    message: err.message
  });
});

// Start server
const PORT = config.port || 422;

app.listen(PORT, () => {
  console.log('=================================');
  console.log('🚀 AI Gateway Server Started');
  console.log('=================================');
  console.log(`📡 Server running on: http://localhost:${PORT}`);
  console.log(`🌐 Web UI: http://localhost:${PORT}`);
  console.log(`🔗 Ollama endpoint: ${config.ollama.baseUrl}`);
  console.log('=================================');
  console.log('');
  console.log('Available endpoints:');
  console.log(`  GET  /health          - Health check`);
  console.log(`  GET  /models          - List all mappings`);
  console.log(`  POST /models          - Add new mapping`);
  console.log(`  PUT  /models/:alias   - Update mapping`);
  console.log(`  DELETE /models/:alias - Delete mapping`);
  console.log(`  POST /:model          - AI Gateway (dynamic)`);
  console.log('=================================');
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully...');
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('\nSIGINT received, shutting down gracefully...');
  process.exit(0);
});

module.exports = app;
