module.exports = {
  port: 422,
  ollama: {
    baseUrl: 'http://103.127.97.215:11434',
    generateEndpoint: '/api/generate'
  }
};
